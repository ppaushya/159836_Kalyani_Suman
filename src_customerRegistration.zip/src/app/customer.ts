export class Customer{
    customerId: number;
    firstName: string;
    lastName: string;
    dateOfBirth:string;
    emailId: string;
    mobile: string;
    customerPassword: string;

}