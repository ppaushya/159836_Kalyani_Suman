package InterfacePractice;

public class Circle implements Shape,Color{
	@Override
	public void draw()
	{
		System.out.println("Class Circle--draw");
	}
	public void info()
	{
		System.out.println("Class Circle--info");
	}

}
