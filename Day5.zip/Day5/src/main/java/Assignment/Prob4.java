/*
 * Write a program in Java which implements interface Student which has
two methods Display_Grade and Atrendance for PG_Students and UG_Students
(PG_Students and UG_Students are two different classes for Post Graduate and
Under Graduate students respectively).
 */
package Assignment;
import java.util.*;
/**
 *
 * @author Admin
 */
public class Prob4 {
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        char grade;
        float attendance;
        grade=sc.next().charAt(0);
        attendance=sc.nextFloat();
        System.out.println("PG details: ");
    StudentInterface pg=new PGStudent("Tom",grade,attendance);
    pg.displayGrade(grade);
    pg.displayattendance(attendance);
    
     System.out.println("UG details: ");
    StudentInterface ug=new UGStudent("Jack",grade,attendance);
   ug.displayGrade(grade);
    ug.displayattendance(attendance);
     
    
    sc.close();
    }
    
}
