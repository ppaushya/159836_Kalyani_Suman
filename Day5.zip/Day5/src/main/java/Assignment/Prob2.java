/*
 * Write a program in Java to show the usefulness of Interfaces as a place to
keep constant value of the program.
 */
package Assignment;

/**
 *
 * @author Admin
 */
public class Prob2 {
    public static void main(String[] args)
    {
        Area rect=new Rectangle();
        Area cr=new Circle();
        System.out.println("Area of rectangle= "+rect.calArea(10,20));
        System.out.println("Area of circle= "+cr.calArea(10,0));
        
    }
}
