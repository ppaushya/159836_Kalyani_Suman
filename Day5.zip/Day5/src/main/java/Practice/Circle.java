//subclass of Shape

package Practice;

public class Circle extends Shape{

	float radius;
	
	public Circle() {
		super();
		System.out.println("Circle class--no argument constructor");

	}
	
	public Circle(float radius) {
		super();
		System.out.println("Circle class--full argument constructor");

		this.radius = radius;
	}

	public float calculateArea()
	{
		return 3.14f*radius*radius;
	}
	@Override
	public void draw()
	{//if implementation not provided here then it is also abstract class. 
		//then concrete class will provide the implementation
		System.out.println("Circle class--draw method");
		
	}
}
