package Practice;

public class Child extends Parent{

	
	public Child()
	{
		//super() bydefault inserted by JVM
		System.out.println("child");
	}
	
	public void show()
	{
		//System.out.println(super.super.num);//super.super illegal
		System.out.println(num);
		System.out.println(super.num);
		super.show();
		
	}

}
