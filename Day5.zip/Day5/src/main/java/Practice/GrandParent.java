package Practice;

public class GrandParent {

	public GrandParent()
	{
		System.out.println("Grand Parent");
	}
		protected int num=1000;
		
	
}
