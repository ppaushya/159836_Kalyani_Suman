package Practice;

import java.util.Scanner;

public class Employee extends Person{

	double salary;
	boolean isPermanent; 
	
	public Employee() {
		//super();
	}
	public Employee(int empId, String fName, String lName,double salary, boolean isPermanent) {

		/*this.personId=empId;
		this.fName=fName;
		this.lName=lName;*/
		super(empId,fName,lName);
		this.salary = salary;
		this.isPermanent = isPermanent;
	}
	public void getEmployee()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Salary");
		salary=sc.nextDouble();
		super.show();
		System.out.println("Enter true or false");
		isPermanent=sc.nextBoolean();
		
	}
	public void showEmployee()
	{
		System.out.println(salary+" "+isPermanent);
	}
	@Override
	public void show()
	{
		System.out.println("Employee Class");
	}

}
