package Practice;

import java.util.Scanner;

//inheritance
public class Person {

	int personId;
	String fName;
	String lName;
	
	public Person() {
		//super();
	}

	public Person(int personId, String fName, String lName) {
//		super();
		this.personId = personId;
		this.fName = fName;
		this.lName = lName;
	}

	public void getPerson()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Person Id");
		personId=sc.nextInt();
		
		System.out.println("Enter Person FName");
		fName=sc.next();
		
		System.out.println("Enter Person LName");
		lName=sc.next();
		
	}
	
	public void showPerson()
	{
		System.out.println(personId+" "+fName+" "+lName);
	}

	public void show()
	{
		System.out.println("Person Class");
	}
}
