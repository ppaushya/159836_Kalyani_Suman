//abstract example Main method
package Practice;

public class TestAbstract {

	public static void main(String[] args) {
		//Shape s=new shape();error bcoz its abstract class
		
		//Circle c=new Circle();
		Circle c=new Circle(3.4f);
				float area=c.calculateArea();
				System.out.println("Area is "+area);
				c.draw();

	}

}
