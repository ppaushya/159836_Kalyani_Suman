package Practice;

public class MainClass {

	public static void main(String[] args) {
//		Employee emp=new Employee();
		
		Employee emp3=new Employee(121,"tom","jack",2000,true);
		/*emp.getPerson();
		emp.getEmployee();
		
		emp.showPerson();
		emp.showEmployee();*/
		emp3.showPerson();
		emp3.showEmployee();
//		Person per=new Employee();//per can access only parent class-Person members
		//JVM loads only Person class into memory
		
		
		//Employee emp=new Person();visibility is lost...cannot refer
		
		//Override
		emp3.show();
		Person per=new Employee();
		per.show();
	}

}
