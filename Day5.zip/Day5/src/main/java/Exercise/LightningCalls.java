package Exercise;

public class LightningCalls extends Calls{

	/*public LightningCalls() {
		super();
	}*/
	public LightningCalls(int hrs) {
		super(hrs);
	}
	
	public int charge(int hrs)
	{
		return 5*hrs;
	}
}
