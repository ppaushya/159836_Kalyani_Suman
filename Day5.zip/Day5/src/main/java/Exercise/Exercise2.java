package Exercise;

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Calls u=new UrgentCall(10);
		Calls o=new OrdinaryClass(10);
		Calls l=new LightningCalls(10);
		
		System.out.println("Charge on urgent call "+u.charge(10));
		System.out.println("Charge on ordinary call "+o.charge(10));
		System.out.println("Charge on lightning call "+l.charge(10));
	}

}
/*Consider the trunk calls of a telephone exchange. A trunk call can be
ordinary, urgent or lightning. The charges depend on the duration and the type of the
call. Writ a program using the concept of polymorphism in Java to calculate the
charges.*/