package Exercise;

public abstract class Worker {

	String name;
	int salaryRate;
	int hrs;
	
	public Worker() {
		super();
	}

	public Worker(String name, int salaryRate) {
		super();
		this.name = name;
		this.salaryRate = salaryRate;
	}

	public Worker(String name, int salaryRate, int hrs) {
		super();
		this.name = name;
		this.salaryRate = salaryRate;
		this.hrs = hrs;
	}

	public int getSalaryRate()
	{
		return salaryRate;
	}
	
	public int getHrs()
	{
		return hrs;
	}
	public abstract float comPay(int hrs);
	
	

	}


