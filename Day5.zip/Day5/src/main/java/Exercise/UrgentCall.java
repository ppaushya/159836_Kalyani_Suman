package Exercise;

public class UrgentCall extends Calls{

	/*public UrgentCall() {
		super();
	}*/
	public UrgentCall(int hrs) {
		super(hrs);
	}
	
	public int charge(int hrs)
	{
		return 10*hrs;
	}
}
