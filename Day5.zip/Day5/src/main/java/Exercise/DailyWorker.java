package Exercise;

public class DailyWorker extends Worker{

	public DailyWorker(String name,int hrs,int salaryRate)
	{
		super( name, hrs, salaryRate);
	}
	
	public float comPay(int hrs)
	{
		return hrs*getSalaryRate() / 24;
	}

}
