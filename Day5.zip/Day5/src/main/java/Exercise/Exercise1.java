package Exercise;

public class Exercise1 {

	public static void main(String[] args) {

		Worker w1 =new DailyWorker("abc",5000,48);
		Worker w2=new SalaryWorker("abc",5000);
		
		System.out.println(w1.comPay(w1.getHrs()));
		System.out.println(w2.comPay(w2.getHrs()));
	}

}
/*Write a class Worker and derive classes DailyWorker and
SalariedWorker from it. Every worker has a name and a salary rate. Write method
ComPay (int hours) to compute the week pay of every worker. A Daily Worker is
paid on the basis of the number of days s/he works. The Salaried Worker gets paid
the wage for 40 hours a week no matter what the actual hours are. Test this program
to calculate the pay of workers. You are expected to use the concept of polymorphism
to write this program.*/