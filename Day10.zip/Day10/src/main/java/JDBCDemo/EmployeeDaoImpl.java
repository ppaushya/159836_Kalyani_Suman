package JDBCDemo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements IEmployeeDao{

	private Connection getDbConnection() {
		Connection conn=null;
		try{
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
	
			Class.forName("com.mysql.jdbc.Driver");
			return conn;
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return null;
		
		
	}

	@Override
	public void createEmployee(EmployeeDB emp) {
		Connection conn=getDbConnection();
//		String sql="Insert into employee values(987,'kamal','hasan',3000,'11-05-2018')";
		String sql="Insert into employee values(?,?,?,?,?)";
		try {
			
			/*Statement  statement=conn.createStatement();
			int count=statement.executeUpdate(sql);*/
			
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setInt(1,emp.getEmpId());
			statement.setString(2,emp.getfName());
			statement.setString(3, emp.getlName());
			statement.setInt(4, emp.getSalary());
			statement.setDate(5,java.sql.Date.valueOf(emp.getDate()));
			
			int count=statement.executeUpdate();
			if(count!=0)
			{
				System.out.println("Row Inserted!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteEmployee(int employeeId) {
		String sql="delete from employee where empid=?";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, employeeId);
			
			int count=pst.executeUpdate();
			if(count>0)
				System.out.println("Deletion Done!");
			else
				System.out.println("Deletion Error!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

	@Override
	public List<EmployeeDB> getAllEmployees() {
		List<EmployeeDB> employees=new ArrayList<>();
		
		String sql="select * from employee";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {
				EmployeeDB employee=new EmployeeDB();
				employee.setEmpId(resultSet.getInt(1));
				employee.setfName(resultSet.getString("firstName"));
				employee.setlName(resultSet.getString("lastName"));
				employee.setSalary(resultSet.getInt("salary"));
				employee.setDate(resultSet.getDate(5).toLocalDate());
				employees.add(employee);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return employees;
	}

	@Override
	public List<EmployeeDB> findEmployee(int empId) {
		List<EmployeeDB> employees=new ArrayList<>();
		String sql="select * from employee where empid=?";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, empId);
			
			ResultSet resultSet=pst.executeQuery();
			while(resultSet.next()) {
				EmployeeDB employee=new EmployeeDB();
				employee.setEmpId(resultSet.getInt(1));
				employee.setfName(resultSet.getString("firstName"));
				employee.setlName(resultSet.getString("lastName"));
				employee.setSalary(resultSet.getInt("salary"));
				employee.setDate(resultSet.getDate(5).toLocalDate());
				employees.add(employee);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return employees;
	}

	@Override
	public void updateFirstName(String fName,int empId) {
		String sql="update employee set firstName=? where empId=?";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, fName);
			pst.setInt(2, empId);
			
			int count=pst.executeUpdate();
			if(count>0)
				System.out.println("Updation Done!");
			else
				System.out.println("Updation Error!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
	}

	@Override
	public void updateLastName(String lName,int empId) {
		String sql="update employee set lastName=? where empId=?";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, lName);
			pst.setInt(2, empId);
			
			int count=pst.executeUpdate();
			if(count>0)
				System.out.println("Updation Done!");
			else
				System.out.println("Updation Error!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}

	@Override
	public void updateDoj(LocalDate doj,int empId) {
		String sql="update employee set empdoj=? where empId=?";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			/*pst.setString(1, doj);
			pst.setInt(2, empId);*/
			
			int count=pst.executeUpdate();
			if(count>0)
				System.out.println("Updation Done!");
			else
				System.out.println("Updation Error!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}

	@Override
	public void updateSalary(int sal,int empId) {
		String sql="update employee set salary=? where empId=?";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, sal);
			pst.setInt(2, empId);
			
			int count=pst.executeUpdate();
			if(count>0)
				System.out.println("Updation Done!");
			else
				System.out.println("Updation Error!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}

	@Override
	public EmployeeDB callProcedure(int employeeId) {
try(Connection conn=getDbConnection()){
			
			CallableStatement callableStatement=conn.prepareCall("{ call  findEmployee(?,?,?,?)}");
			callableStatement.setInt(1, employeeId);
			callableStatement.registerOutParameter(2,Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.INTEGER);
			
			callableStatement.execute();
			
			String fname=callableStatement.getString(2);
			String lname=callableStatement.getString(3);
			int salary=callableStatement.getInt(4);
			
			EmployeeDB employee=new EmployeeDB();
			employee.setfName(fname);
			employee.setlName(lname);
			employee.setSalary(salary);
			employee.setEmpId(employeeId);
			
			
			return employee;
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public void callBulkInsertion() {
		// TODO Auto-generated method stub
		
	}
}
