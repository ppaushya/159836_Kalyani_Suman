package JDBCDemo;

import java.time.LocalDate;
import java.util.List;

public interface IEmployeeDao {

	public void createEmployee(EmployeeDB employee);
	public void deleteEmployee(int employeeId);
	
	public List<EmployeeDB>  getAllEmployees();
	public List<EmployeeDB> findEmployee(int empId);
	public void updateFirstName(String fName,int empId);
	public void updateLastName(String lName,int empId);
	
	public void updateDoj(LocalDate doj,int empId);
	public void updateSalary(int salary,int empId);
	
	public EmployeeDB callProcedure(int employeeId);
	public void callBulkInsertion();
	
}
