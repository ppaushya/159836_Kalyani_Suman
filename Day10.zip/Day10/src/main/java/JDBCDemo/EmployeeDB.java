package JDBCDemo;

import java.time.LocalDate;

public class EmployeeDB {
	
	private int empId;
	private String fName;
	private String lName;
	private int salary;
	private LocalDate date;
	
	
	public EmployeeDB() {
		super();
	}


	public EmployeeDB(int empId, String fName, String lName, int salary, LocalDate date) {
		super();
		this.empId = empId;
		this.fName = fName;
		this.lName = lName;
		this.salary = salary;
		this.date = date;
	}


	public int getEmpId() {
		return empId;
	}


	public void setEmpId(int empId) {
		this.empId = empId;
	}


	public String getfName() {
		return fName;
	}


	public void setfName(String fName) {
		this.fName = fName;
	}


	public String getlName() {
		return lName;
	}


	public void setlName(String lName) {
		this.lName = lName;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}


	public LocalDate getDate() {
		return date;
	}


	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	

}
