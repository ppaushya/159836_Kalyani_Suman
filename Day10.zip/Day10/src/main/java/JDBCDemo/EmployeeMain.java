package JDBCDemo;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain {

	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		UserInteraction userInteraction=new UserInteraction();
		IEmployeeDao employeeDao=new EmployeeDaoImpl();
		EmployeeDB employee=new EmployeeDB();
		int option;
		String choice;
		do {
		System.out.println("1.Create Employee");
		System.out.println("2.Update Employee");
		System.out.println("3.Delete Employee");
		System.out.println("4.List All Employee");
		System.out.println("5.Find Employee");
		System.out.println("6.Exit");
		System.out.println("Enter your option:");
		option=scanner.nextInt();
			switch(option) {
			case 1:
			//	Employee employee=new Employee(789, "Kamal", "jERRY", 23000, LocalDate.of(2010,3,12));
				employee=userInteraction.createEmployee();
				employeeDao.createEmployee(employee);
				break;
			case 2:
				System.out.println("Enter emp id to be updated: ");
				int empId=scanner.nextInt();
				System.out.println("1.Update first name");
				System.out.println("2.Update last name");
				System.out.println("3.Update salary");
				System.out.println("4.Update date");
				System.out.println("5.Find employee");
				System.out.println("6.Call Stored Procedure");
				System.out.println("7.Bulk Operation");
				System.out.println("8.Exit");
				option=scanner.nextInt();
				switch(option)
				{
				case 1:
					System.out.println("Enter First Name");
					String fName=scanner.next();
					employeeDao.updateFirstName(fName,empId);
					break;
				case 2:
					System.out.println("Enter Last Name");
					String lName=scanner.next();
					employeeDao.updateLastName(lName,empId);
					break;
				case 3:
					System.out.println("Enter salary");
					int salary=scanner.nextInt();
					employeeDao.updateSalary(salary,empId);
					break;
				case 4:
					System.out.println("Enter Employee DateOf Joining[yyyy-mm-dd]:");
					String[] date=scanner.next().split("-");
					LocalDate doj=LocalDate.of(
							Integer.parseInt(date[0]), 
							Integer.parseInt(date[1]), 
							Integer.parseInt(date[2]));
					employeeDao.updateDoj(doj,empId);
					break;
				}
				
				break;
			case 3:
				empId=userInteraction.promptEmployeeID();
				employeeDao.deleteEmployee(empId);
				break;
			case 4:
				List<EmployeeDB> employees= employeeDao.getAllEmployees();
				userInteraction.printAllEmployees(employees);
				break;
			case 5:
				System.out.println("Enter Employee Id to be found: ");
				 empId=scanner.nextInt();
				 employees=employeeDao.findEmployee(empId);
				 userInteraction.printAllEmployees(employees);
				break;
			case 6:
				int emplyId=userInteraction.promptEmployeeID();
				EmployeeDB employee2= employeeDao.callProcedure(emplyId);
				System.out.println(employee2);
				break;
			case 7:
				employeeDao.callBulkInsertion();
				break;
			case 8:
				System.exit(0);
			default:
				System.out.println("Sorry! Invalid Option!");
			}
			System.out.println("You wish to continue[y|n]:");
			choice=scanner.next();
			
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		}


}
