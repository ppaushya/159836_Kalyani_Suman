package Practice;

public class Salary {

}
