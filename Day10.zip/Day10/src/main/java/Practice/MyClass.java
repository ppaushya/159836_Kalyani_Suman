package Practice;

public class MyClass {

	Calculate obj=new Calculate();
	Employee emp=new Employee();
	Salary sal =new Salary();
	System.out.println("Sum is "+obj.sum(emp,10));
	System.out.println("Sum is "+obj.sum(sal,20));
	
}
