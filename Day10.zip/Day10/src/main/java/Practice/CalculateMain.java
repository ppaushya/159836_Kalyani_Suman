package Practice;

public class CalculateMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculate<Integer,Double> obj=new Calculate<>();
		
		obj.setNum1(10);
		obj.setNum2(22.2);
		
		System.out.println("Sum is "+ (obj.getNum1() + obj.getNum2()));

	}

}
