package Practice;

public class Employee {

	
}
