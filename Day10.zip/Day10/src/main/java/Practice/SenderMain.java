package Practice;

public class SenderMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Sender<String> str=new Sender<>();
		str.setMessage("Type is string");
		System.out.println(str.getMessage());
		
		Sender<Integer> myData=new Sender<>();
		str.setMessage("Type is Integer");
		System.out.println(str.getMessage());
		
		Sender sender=new Sender<>();//any type is possible
		str.setMessage("12.400");
		System.out.println(str.getMessage());
		
	}

}
