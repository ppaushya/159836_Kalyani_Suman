import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustService } from '../customer.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  _listFilter: string ='name';
    filteredCustomer: Customer[];
  customers: Customer[];

  constructor(private _custService: CustService) { }

  ngOnInit() {
    this.getCustomers();
    this._custService.getCustomers()
    .subscribe(customers=> {
        this.customers=customers;
        this.filteredCustomer=this.customers;
    },
  }

  getCustomers(): void{
    this._custService.getCustomers()
    .subscribe(customers => this.customers = customers);
  }

  deleteCustomers(customerId : number) {
    this._custService.deleteCustomers(customerId).subscribe();
  }

  updateCustomers(customerId : number) {

  }

  get listFilter() :string{
    return this._listFilter;
}
set listFilter(value:string) {
    this._listFilter=value;
    this.filteredCustomer=this.listFilter ? this.performFilter(this.listFilter):this.customers;

}

performFilter(filterBy:string):Customer []{
    filterBy=filterBy.toLocaleLowerCase();
    return this.customers.filter((product:Customer)=>
     product.firstName.toLocaleLowerCase().indexOf(filterBy)!==-1);
}
}

