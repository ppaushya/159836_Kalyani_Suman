import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustService } from '../customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  customers: Customer[];
  constructor(private _custService: CustService) { }

  ngOnInit() {
   
  }

}
