export class Customer{
    customerId: Number;
    firstName: String;
    lastName: String;
    dateOfBirth:String;
    emailId: String;
    mobile: String;
    customerPassword: String;

}