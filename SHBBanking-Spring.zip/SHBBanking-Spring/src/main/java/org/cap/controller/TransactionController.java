package org.cap.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.cap.service.ITransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TransactionController {

	@Autowired
	private ITransactionService transactionService;
	
	@PostMapping("/depositWithdrawAmt")
	public String depositWithdrawAmt(@Valid @ModelAttribute("depositWithdrawal") Transaction transaction)  {
		if(transaction.getTransactionType().toUpperCase().equals("DEPOSIT"))
		{
			transaction.setToAccount(transaction.getFromAccount());
			transaction.setFromAccount(0);
		}
		if(transactionService.createTransaction(transaction))
			{
				return "transactionPerformed";
			}
		return "redirect:/";
	}
	
	@PostMapping("/fundTransfer")
	public String performFundTransfer(@Valid @ModelAttribute("fundTransfer") Transaction transaction)  {
		
		if(transactionService.createTransaction(transaction))
			{
				return "transactionPerformed";
			}
		return "redirect:/";
	}
	
	@PostMapping("/transactionSummary")
	public String getTransactionSummary(@RequestParam("fromDate") String fromDateString,
			@RequestParam("toDate") String toDateString, HttpSession session, ModelMap map)	{
		System.out.println(fromDateString);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate fromDate=LocalDate.parse(fromDateString, formatter);
		LocalDate toDate=LocalDate.parse(toDateString, formatter);
		
		int customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Transaction> transactions=
				transactionService.getTransactionsForCustomer(customerId, fromDate, toDate);
		
		System.out.println(transactions);
		
		map.addAttribute("customerTransactions", transactions);
		
		Map<Account, Double> currentBalanceDetails=
				transactionService.getCurrentBalance(customerId);
		
		map.addAttribute("currentBalDetails", currentBalanceDetails);
		
		return "transactionSummaryResult";
	}
	
}
