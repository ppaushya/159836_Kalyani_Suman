package org.cap.service;

import java.util.List;

import org.cap.model.RegisterBean;

public interface IRegisterService {

	public boolean registerDetails(RegisterBean registerBean);
	public List<RegisterBean> getAllRegistrations();
	public void deleteRegistration(int customerId);
	public RegisterBean findRegistration(int customerId);
	public void updateRegistration(RegisterBean registerBean);
}
