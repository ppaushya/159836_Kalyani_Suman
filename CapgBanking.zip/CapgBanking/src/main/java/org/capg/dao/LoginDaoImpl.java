package org.capg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		
		String sql="select * from customer where emailId=? and customerPwd=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)) {
			
			pst.setString(1, loginBean.getUserName());
			pst.setString(2, loginBean.getUserPassword());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	
	private Connection getMysqlDbConnection() {
		
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}


	@Override
	public Customer createCustomer(Customer customer) {
		String query = "INSERT INTO customer (firstName ,lastName,dateOfBirth,emailId,mobile,customerPwd) VALUES(?,?,?,?,?,?)";
		try(Connection connection = getMysqlDbConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			//statement.setInt(1,customer.getCustomerId());
			statement.setString(1,customer.getFirstName());
			statement.setString(2,customer.getLastName());
			statement.setDate(3,java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(4, customer.getEmailId());
			statement.setString(5, customer.getMobileNo());
			statement.setString(6,customer.getCustomerPwd());
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Customer info inserted");
				query="select * from customer";
				statement=connection.prepareStatement(query);
				ResultSet resultSet= statement.executeQuery();
				Customer  customer1=new Customer();
				while(resultSet.next()) {
					customer1.setCustomerId(resultSet.getInt(1));
					customer1.setFirstName(resultSet.getString(2));
					customer1.setLastName(resultSet.getString(3));
					customer1.setDateOfBirth(resultSet.getDate(4).toLocalDate());
					customer1.setEmailId(resultSet.getString(5));
					customer1.setMobileNo(resultSet.getString(6));
					customer1.setCustomerPwd(resultSet.getString(7));
				}
				return customer1;
			}else {System.out.println("Error occured.");}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public Account createCustomer(Account account) {
		
		String sql="insert into account values(?,?,?,?,?,?)";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			
			pst.setString(2, account.getAccountType().toString());
			pst.setDate(3,Date.valueOf(account.getOpeningDate()));
			pst.setDouble(4, account.getOpeningBalance());
			pst.setString(5, account.getDescription());
			pst.setInt(6, account.getCustomer().getCustomerId());
			int count=pst.executeUpdate();
			if(count>0)
				return account;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}

}
