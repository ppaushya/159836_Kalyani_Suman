package org.capg.utility;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Transaction;

public class Util {

	public double findCurrentBalance(Account account,List<Transaction> transactions) {
		double currentBalance=account.getOpeningBalance();
		for(Transaction trans:transactions) {
			if(trans.getFromAccount()==account.getAccountNumber() && trans.getTransactionType().equals("Credit"))
			{
				currentBalance+=trans.getAmount();
			}
			else if(trans.getFromAccount()==account.getAccountNumber() && trans.getTransactionType().equals("Debit"))
			{
				currentBalance-=trans.getAmount();
			}
			else if(trans.getToAccount()==account.getAccountNumber() && trans.getTransactionType().equals("Funds"))
			{
				currentBalance+=trans.getAmount();
			}
			else if(trans.getFromAccount()==account.getAccountNumber() && trans.getTransactionType().equals("Funds"))
			{
				currentBalance-=trans.getAmount();
			}
		}
			
		return currentBalance;
		
	}
}
