package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/registerServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {

		ILoginService loginService=new LoginServiceImpl();
		
		//Capture the data from View
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String dateOfBirth=request.getParameter("dateOfbirth");
		String emailId=request.getParameter("email");
		String mobileNo=request.getParameter("mobile");
		String customerPwd=request.getParameter("custPwd");
		
		String addressLine1=request.getParameter("addressline1");
		String addressLine2=request.getParameter("addressline2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String pincode=request.getParameter("pincode");
		Address address=new Address();
		address.setAddressLine1(addressLine1);
		address.setAddressLine2(addressLine2);
		address.setCity(city);
		address.setState(state);
		address.setPincode(pincode);
		
		
		
		//Convert the input into Model
		Customer customer=new Customer();
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		String[] date=dateOfBirth.split("-");
		
		customer.setDateOfBirth(LocalDate.of(Integer.parseInt(date[0]), Integer.parseInt(date[1]),
				Integer.parseInt(date[2])));
		customer.setEmailId(emailId);
		customer.setMobile(mobileNo);
		customer.setCustomerPwd(customerPwd);
		customer.setAddress(address);
		
		//Customer customer1=loginService.createCustomer(customer);
		
		 
	        
		if(loginService.createCustomer(customer))
			{
			PrintWriter out=response.getWriter();
			out.println(" Customer Registered");
			response.sendRedirect("index.html");
			}
		else
			response.sendRedirect("index.html");
	}

}
