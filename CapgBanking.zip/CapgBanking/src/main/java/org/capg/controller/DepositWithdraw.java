package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

/**
 * Servlet implementation class DepositWithdraw
 */
@WebServlet("/DepositWithdraw")
public class DepositWithdraw extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ILoginService loginService=new LoginServiceImpl();
		//creating session
		
		loginService.getAllAccount();
		

		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		
		out.println();
		
	}

}
