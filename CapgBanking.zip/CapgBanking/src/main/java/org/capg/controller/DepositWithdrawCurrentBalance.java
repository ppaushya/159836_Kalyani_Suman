package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

/**
 * Servlet implementation class DepositWithdrawCurrentBalance
 */
@WebServlet("/DepositWithdrawCurrentBalance")
public class DepositWithdrawCurrentBalance extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession session=request.getSession();
		int customerID=(Integer)session.getAttribute("custId");
		//System.out.println(request.getParameter("account"));
		int accNo=Integer.parseInt(request.getParameter("account"));
		double amount=Double.parseDouble(request.getParameter("amount"));
		//System.out.println(amount);
		String transactionType=request.getParameter("creditOrDebit");
		
		ILoginService loginService=new LoginServiceImpl();
		double currentBalance=loginService.getCurrentBalance(customerID, accNo);
		//System.out.println(amount);
		if( transactionType.equals("Debit") && currentBalance < amount )
		{
			System.out.println("Current balance="+currentBalance+". Please enter amount less than current Balance");
			session.setAttribute("errMsg", "Please enter amount less than current Balance");
			response.sendRedirect("ErrorMessageServlet");
		}
		else 
		{
			System.out.println(amount);
			String description=request.getParameter("description");
			Transaction transaction=new Transaction();
			transaction.setFromAccount(accNo);
			transaction.setToAccount(0);
			transaction.setDescription(description);
			transaction.setTransactionType(transactionType);
			transaction.setAmount(amount);
			transaction.setTransactionDate(LocalDate.now());
			Customer customer=new Customer();
			customer.setCustomerId(customerID);
			transaction.setCustomer(customer);
			
			if(loginService.addTransactionDetails(transaction))
			{
				session.setAttribute("successMsg", "Transaction Successful");
				response.sendRedirect("SuccessMessageServlet");
			}
			
		}
		
		
		
		
		
	}

}
