package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {
	
	private WebDriver driver;
	
	@Before
	public void setUp() {
		//Loading the driver
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kalsuman\\Downloads\\chromedriver.exe");
				
		//Initialize chrome driver
		driver=new ChromeDriver();
	}
	
	@Given("^Open CapgBanking login page$")
	public void open_CapgBanking_login_page() throws Throwable {
		
		driver.get("http://localhost:8081/CapgBanking/");
	}

	@Given("^provide username and password$")
	public void provide_username_and_password() throws Throwable {
	    
		driver.findElement(By.name("userName")).sendKeys("tom@gmail.com");
		
		driver.findElement(By.name("userPwd")).sendKeys("tom123");
	}

	@When("^submit validate login$")
	public void submit_validate_login() throws Throwable {
	   
		WebElement element=driver.findElement(By.name("login"));
		
		element.submit();
	}

	@Then("^navigate to mainPage$")
	public void navigate_to_mainPage() throws Throwable {
	 
		driver.navigate().to("http://localhost:8081/CapgBanking/loginServlet");
	}

	@Given("^provide invalid username and password$")
	public void provide_invalid_username_and_password() throws Throwable {
	    
		driver.findElement(By.name("userName")).sendKeys("tom@gmail.com");;
		
		driver.findElement(By.name("userPwd")).sendKeys("tom456");
	}

	@When("^submit invalid login$")
	public void submit_invalid_login() throws Throwable {
	    
		WebElement element=driver.findElement(By.name("login"));
		
		element.submit();
		
	}

	@Then("^redirect to same page$")
	public void redirect_to_same_page() throws Throwable {
	    
		driver.navigate().to("http://localhost:8081/CapgBanking/index.html");
	}

	
	@After
	public void tearDown() {
		
		driver.quit();
		
	}
}
