package register;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {
	
	private WebDriver driver;
	
	@Before
	public void setUp() {
		//Loading the driver
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kalsuman\\Downloads\\chromedriver.exe");
				
		//Initialize chrome driver
		driver=new ChromeDriver();
	}
	
	@Given("^Open login page$")
	public void open_login_page() throws Throwable {
	    
		driver.get("http://localhost:8081/CapgBanking/");
		Thread.sleep(1000);
	}
	
	@When("^Signup button clicked$")
	public void signup_button_clicked() throws Throwable {
	 
		WebElement element=driver.findElement(By.name("signup"));
		Thread.sleep(1000);
		
		element.submit();
		Thread.sleep(1000);
		
	}

	@Then("^navigate to register page$")
	public void navigate_to_register_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/CapgBanking/view/registration.html");
		Thread.sleep(1000);
	}

	@Given("^Open register page$")
	public void open_register_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/CapgBanking/view/registration.html");
			Thread.sleep(1000);
	}

	@Given("^User Details$")
	public void user_Details() throws Throwable {
		driver.findElement(By.name("firstName")).sendKeys("kalyani");Thread.sleep(1000);
		
		driver.findElement(By.name("lastName")).sendKeys("Suman");Thread.sleep(1000);
		
		driver.findElement(By.name("dateOfbirth")).sendKeys("10-10-1996");Thread.sleep(1000);
		
		driver.findElement(By.name("addressline1")).sendKeys("new south");Thread.sleep(1000);
		
		driver.findElement(By.name("addressline2")).sendKeys("walker street");Thread.sleep(1000);
		
 		Select dropdown = new Select(driver.findElement(By.id("city")));Thread.sleep(1000);
		   dropdown.selectByVisibleText("Chennai"); 
		   
		 WebElement radioBtn = driver.findElement(By.id("TamilNadu"));
		 radioBtn.click(); Thread.sleep(1000);
		
		driver.findElement(By.name("pincode")).sendKeys("123456");Thread.sleep(1000);
		
		driver.findElement(By.name("email")).sendKeys("kalyani@gmail.com");Thread.sleep(1000);
		
		driver.findElement(By.name("mobile")).sendKeys("9874563211");Thread.sleep(1000);
		
		driver.findElement(By.name("custPwd")).sendKeys("kalyani");Thread.sleep(1000);
		
		driver.findElement(By.name("confirmCustPwd")).sendKeys("kalyani");Thread.sleep(1000);
		
	}

	@When("^Register button clicked$")
	public void register_button_clicked() throws Throwable {
	 
		WebElement element=driver.findElement(By.name("register"));
		Thread.sleep(1000);
		
		element.submit();
		Thread.sleep(1000);
	}

	@Then("^navigate to index page$")
	public void navigate_to_index_page() throws Throwable {
		driver.navigate().to("http://localhost:8081/CapgBanking/index.html");
		Thread.sleep(1000);
	}



	@After
	public void tearDown() {
		
		driver.quit();
		
	}
}
