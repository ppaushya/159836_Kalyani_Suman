package org.cap.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public class PilotImpl  implements IPilotDao{
	
	private static AtomicInteger pilotId=new AtomicInteger(1000);
	private static List<Pilot> pilots=dummyDB();
	
	private static List<Pilot> dummyDB(){
		List<Pilot> pilots=new ArrayList<>();
		
		pilots.add(new Pilot(pilotId.incrementAndGet(), "tom", true, 120000,Date.valueOf(LocalDate.of(1990, 2, 23))));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Jack", false, 4354353,Date.valueOf(LocalDate.of(1970, 2, 23))));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Jerry", false, 32432,Date.valueOf(LocalDate.of(1991, 6, 12))));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "kamal", true, 898787,Date.valueOf(LocalDate.of(2000, 7, 9))));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Lee", false, 120000,Date.valueOf(LocalDate.of(1990, 2, 11))));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Annie", true, 123233,Date.valueOf(LocalDate.of(1987, 8, 21))));
		
		return pilots;
	}

	@Override
	public List<Pilot> getAllPilots() {
		
		return pilots;
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		Iterator<Pilot> pilot = pilots.iterator();
		while (pilot.hasNext()) {
		   Pilot o = pilot.next();
		 
		   if(o.getPilotId()==pilotId)
		   {
			   pilot.remove();
			   return pilots;
		   }
		}
		
		return null;
	}

	@Override
	public List<Pilot> findPilot(Integer pilotId) {
		Iterator<Pilot> pilot = pilots.iterator();
		while (pilot.hasNext()) {
		   Pilot o = pilot.next();
		 
		   if(o.getPilotId()==pilotId)
		   {
			   return pilots;
		   }
		}
		return null;
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilots.add(pilot);
		return pilots;
	}

	@Override
	public List<Pilot> updatePilot(Pilot pilot,int pilotId) {
		
		Iterator<Pilot> itr = pilots.iterator();
		while (itr.hasNext()) {
		   Pilot o = itr.next();
		 
		   if(o.getPilotId()==pilotId)
		   {
			   itr.remove();
			 
		   }
		}
		pilots.add(pilot);
		
		return pilots;
	}
	
	

}
