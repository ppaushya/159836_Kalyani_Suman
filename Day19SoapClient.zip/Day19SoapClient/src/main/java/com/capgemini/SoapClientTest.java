package com.capgemini;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class SoapClientTest {

	public static void main(String[] args) throws MalformedURLException {
		URL url=new URL("http://localhost:7709/ws/ICalculator?wsdl");
		
		QName qname=new QName("http://capgemini.com/","CalculatorImplService");
		
		Service service=Service.create(url, qname);
		
		ICalculator calculator=service.getPort(ICalculator.class);
		
		System.out.println("Add number method: "+calculator.addNumber(10, 20));
		
	}

}
