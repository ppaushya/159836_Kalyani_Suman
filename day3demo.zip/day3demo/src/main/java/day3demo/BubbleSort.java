package day3demo;

import java.util.Scanner;

public class BubbleSort {

	Scanner sc=new Scanner(System.in);
	int[] myArr;
	public void getElements(int size)
	{
		myArr=new int[size];
		System.out.println("Enter the elements of array: ");
		for(int i=0;i<size;i++)
		{
			myArr[i]=sc.nextInt();
		}
		
	}
	public void sort()
	{
		boolean swap=false;
		int size=myArr.length;
		int temp;
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{swap=false;
				if(myArr[i]>myArr[j])
				{
					swap=true;
					temp=myArr[i];
					myArr[i]=myArr[j];
					myArr[j]=temp;
				}
			}
			if(swap==false)
				break;
		}
	}
	public void printArray()
	{
		System.out.println("Elements of MyArray are : ");
		for(int i=0;i<myArr.length;i++)
		{
			System.out.println(myArr[i]);
		}
	}
	public static void main(String[] args) {
		BubbleSort obj=new BubbleSort();
		obj.getElements(5);
		System.out.println("Before sorting:");
		obj.printArray();
		System.out.println("After sorting:");
		obj.sort();
		obj.printArray();

	}

}
