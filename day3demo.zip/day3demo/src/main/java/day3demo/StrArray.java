package day3demo;

import java.util.Scanner;

public class StrArray {
	Scanner sc=new Scanner(System.in);
	String[] str;
	public void acceptString(int size)
	{
		str=new String[size];
		System.out.println("Enter the elements of string array: ");
		for(int i=0;i<size;i++)
		{
			str[i]=sc.nextLine();
		}
	}
	
	public void printString()
	{
		int size=str.length;
		System.out.println("Elements of string array are : ");
		for(int i=0;i<size;i++)
		{
			System.out.println(str[i]);
		}
	}
	
	public void reverseArray()
	{
		int size=str.length;
		String temp;
		for(int i=0;i<size/2;i++)
		{
			temp=str[i];
			str[i]=str[size-1-i];
			str[size-1-i]=temp;
		}
	}
	//str[0].compareTo(str[1])>1;
	//compareToIgnore
	public void sortArray()
	{
		int size=str.length;
		String temp;
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{
				if(str[i].compareTo(str[j])>1)
				{
					temp=str[i];
					str[i]=str[j];
					str[j]=temp;
				}
					
			}
		}
	}
	public static void main(String[] args) {
		
		StrArray obj=new StrArray();
		obj.acceptString(5);
		obj.printString();
		System.out.println("After reversing :");
		obj.reverseArray();
		obj.printString();
		System.out.println("After sorting :");
		obj.sortArray();
		obj.printString();
	}

}
