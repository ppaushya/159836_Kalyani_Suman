package day3demo;

import java.util.Scanner;

public class ReverseArray {

	Scanner sc=new Scanner(System.in);

	int[] revArr;
	public void getElements(int size)
	{
		 revArr=new int[size];
			System.out.println("Enter the elements of array: ");
			for(int i=0;i<size;i++)
			{
				revArr[i]=sc.nextInt();
			}
		
	}
	public void printArray()
	{
		System.out.println("Elements of MyArray are : ");
		for(int i=0;i<revArr.length;i++)
		{
			System.out.println(revArr[i]);
		}
	}
	public void reverseArray()
	{
		int size=revArr.length;
		int temp;
		for(int i=0;i<size/2;i++)
		{
			temp=revArr[i];
			revArr[i]=revArr[size-1-i];
			revArr[size-1-i]=temp;
		}
		
	}
	public static void main(String[] args) {
		ReverseArray obj=new ReverseArray();
		obj.getElements(5);
		obj.printArray();
		obj.reverseArray();
		System.out.println("Reverse Array:");
		obj.printArray();
	}

}
