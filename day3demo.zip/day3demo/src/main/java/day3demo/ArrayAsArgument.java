package day3demo;

public class ArrayAsArgument {
	public int[] addArray(int[] num1,int[] num2)
	{
		int[] ans=new int[4];
		for(int i=0;i<4;i++)
		{
			ans[i]=num1[i]+num2[i];
		}
		return ans;
	}

	public static void main(String[] args) {
		int[] num1= {1,2,3,4};
		int[] num2= {10,20,30,40};
		ArrayAsArgument obj=new ArrayAsArgument();
		int[] res=obj.addArray(num1,num2);
		for(int i=0;i<4;i++)
		{
			System.out.print(res[i]+" ");
		}
	}

}
