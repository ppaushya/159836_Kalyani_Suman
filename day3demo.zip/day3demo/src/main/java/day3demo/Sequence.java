package day3demo;

import java.util.Scanner;

public class Sequence {

	Scanner sc=new Scanner(System.in);

	int[] myArr;//instance variable need not to be initialised.Hav value as null
	
	public void getElements(int size)
	{
	 myArr=new int[size];
		System.out.println("Enter the elements of array: ");
		for(int i=0;i<size;i++)
		{
			myArr[i]=sc.nextInt();
		}
		
	}
	public void printArray()
	{
		System.out.println("Elements of MyArray are : ");
		for(int i=0;i<myArr.length;i++)
		{
			System.out.println(myArr[i]);
		}
	}
	
	public void sort()
	{//bubble sort
		boolean swap=false;
		int size=myArr.length;
		int temp;
		for(int i=0;i<size;i++)
		{
			for(int j=i+1;j<size;j++)
			{swap=false;
				if(myArr[i]>myArr[j])
				{
					swap=true;
					temp=myArr[i];
					myArr[i]=myArr[j];
					myArr[j]=temp;
				}
			}
			if(swap==false)
				break;
		}
	}
	public int findSmallElem()
	{
		int n;
		int size=myArr.length;
		for(int i=1;i<size;i++)
		{
			if(myArr[i]-myArr[i-1]!=1)
			{
				n=myArr[i-1];
				return n+1;
			}
		}
		 n=myArr[size-1];
		return (n+ 1);
	}
	public static void main(String[] args) {

		Sequence obj=new Sequence();
		obj.getElements(5);
		obj.printArray();
		obj.sort();
		System.out.println("Smallest missing num in sequence is: "+obj.findSmallElem());
		
	}

}
