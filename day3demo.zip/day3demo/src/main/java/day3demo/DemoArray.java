package day3demo;

import java.util.Scanner;

public class DemoArray {

	Scanner sc=new Scanner(System.in);

	int[] myArr;//instance variable need not to be initialised.Hav value as null
	
	public void getElements(int size)
	{
	 myArr=new int[size];
		System.out.println("Enter the elements of array: ");
		for(int i=0;i<size;i++)
		{
			myArr[i]=sc.nextInt();
		}
		
	}//que1
	public int largestElement()
	{
		int lar=myArr[0];
		int size=myArr.length;
		for(int i=1;i<size;i++)
		{
			if(lar<myArr[i])
				lar=myArr[i];
		}
		return lar;
	}//que2
	public int smallestElement()
	{
		int small=myArr[0];
		int size=myArr.length;
		for(int i=1;i<size;i++)
		{
			if(small>myArr[i])
				small=myArr[i];
		}
		return small;
	}
	//que3
	public int evenElements()
	{
		int size=myArr.length;
		int sum=0;
		for(int i=0;i<size;i++)
		{
			if(myArr[i]%2==0)
			{
				System.out.print(myArr[i]+" ");
				sum+=myArr[i];
			}
		}
		return sum;
	}
	public void printArray()
	{
		System.out.println("Elements of MyArray are : ");
		for(int i=0;i<myArr.length;i++)
		{
			System.out.println(myArr[i]);
		}
	}
	public static void main(String[] args) {
		DemoArray obj=new DemoArray();
		obj.getElements(5);
		obj.printArray();
		System.out.println("The largest element is: "+obj.largestElement());
		System.out.println("The smallest element is: "+obj.smallestElement());
		int sum=obj.evenElements();
		System.out.println("Sum of even element in array is: "+sum);

	}

}
