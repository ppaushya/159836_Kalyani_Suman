package Practice;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
public class CollectionDemo {

	public static void main(String[] args) {

//		ArrayList lst=new ArrayList<>();
		List lst=new ArrayList<>();//most used
		
//		Collection lst=new ArrayList<>();
//		Iterable lst=new ArrayList<>();//less used
		
		
		//collection framework deals with wrapper classes
		//so the primitive is converted to object using wrapper classes
		lst.add(3);
		lst.add("Tom");
		lst.add(45.66);
		lst.add(123564789);
		lst.add(new Object());
		lst.add(123564789);//duplicates allowed
		lst.add(null);//null allowed
		
		System.out.println(lst);
		System.out.println(lst.get(3));
		
		
	}

}
