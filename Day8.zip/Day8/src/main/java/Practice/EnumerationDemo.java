package Practice;

import java.util.ArrayList;
import java.util.List;
import java.util.*;
public class EnumerationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

Vector<String> lst=new Vector<>();
lst.add("tom");
lst.add("jack");
lst.add("jerry");
lst.add("tom");
lst.add("null");

Enumeration<String> enumeration=lst.elements();
while(enumeration.hasMoreElements())
{
	 String s=enumeration.nextElement();          
	 System.out.println(s);    
}
		
		
	}

}
