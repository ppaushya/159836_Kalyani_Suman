package Practice;
import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		List<String> lst=new ArrayList<>();
		
		lst.add("tom");
		lst.add("jack");
		lst.add("jerry");
		lst.add("tom");
		lst.add("null");
		
		//enhance for loop
		for(String str:lst)
			System.out.print(str+" ");
		System.out.println();
		
		//iterator
		Iterator<String> iterator=lst.iterator();//headpointer
		while(iterator.hasNext())//whether there is next element in the list or not
			System.out.print(iterator+" ");
		System.out.println();
		
		//List Iterator
		ListIterator<String> lstIterator=lst.listIterator();
		while(lstIterator.hasNext())
		{
			String s=lstIterator.next();
			System.out.print(s+" ");
		}
		
			
	}

}
