package Practice;

import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vector<Integer> nums=new Vector<>(100);//initial capacity
		
//		Vector<Integer> nums=new Vector<>();//default 10 capacity
//		2*n---incremental capacity
		nums.add(54);
		nums.add(20);
		nums.add(56);
		nums.add(96);
		System.out.println(nums.capacity());
		
	}

}
