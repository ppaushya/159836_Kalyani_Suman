package com.capstore.service;

public class ProductImageService implements IProductImageService{

}
