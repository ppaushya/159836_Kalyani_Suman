package managingCart;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	
	@Given("^product page$")
	public void product_page() throws Throwable {
	    
	}

	@When("^add button is pressed$")
	public void add_button_is_pressed() throws Throwable {
	    
	}

	@Then("^product should be added to cart$")
	public void product_should_be_added_to_cart() throws Throwable {
	   
	}

	@Given("^cart page$")
	public void cart_page() throws Throwable {
	    
	}

	@When("^delete button is pressed$")
	public void delete_button_is_pressed() throws Throwable {
	    
	}

	@Then("^display alert box for confirmation$")
	public void display_alert_box_for_confirmation() throws Throwable {
	    
	}

	@When("^user clicks yes$")
	public void user_clicks_yes() throws Throwable {
	    
	}

	@Then("^delete the product from cart list$")
	public void delete_the_product_from_cart_list() throws Throwable {
	   
	}

	@When("^quantity is selected from the list$")
	public void quantity_is_selected_from_the_list() throws Throwable {
	    
	}

	@Then("^update the price of products$")
	public void update_the_price_of_products() throws Throwable {
	    
	}

	@Then("^update the final cart amount before checking out$")
	public void update_the_final_cart_amount_before_checking_out() throws Throwable {
	    
	}

	@Given("^total amount of purchased products$")
	public void total_amount_of_purchased_products() throws Throwable {
	    
	}

	@When("^total amount is greater than minimum balance$")
	public void total_amount_is_greater_than_minimum_balance() throws Throwable {
	    
	}

	@Then("^proceed to checkout$")
	public void proceed_to_checkout() throws Throwable {
	    
	}



}
