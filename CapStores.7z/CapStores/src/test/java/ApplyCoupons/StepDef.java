package ApplyCoupons;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	@Given("^Request for Verifying Coupons$")
	public void request_for_Verifying_Coupons() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^There exist a valid coupon code$")
	public void there_exist_a_valid_coupon_code() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Calculate the Discounted price$")
	public void calculate_the_Discounted_price() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Reflect on final bill$")
	public void reflect_on_final_bill() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^There isnt a valid coupon code$")
	public void there_isnt_a_valid_coupon_code() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Decline the request$")
	public void decline_the_request() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
