package StaticNestedClass;

public class StaticNestedClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println(OuterClass2.outer_x);
		// accessing a static nested class 
        OuterClass2.StaticNestedClass nestedObject = new OuterClass2.StaticNestedClass(); 
          
        nestedObject.display(); 
        //nestedObject.show();will work
        
        OuterClass2.StaticNestedClass.show();
	}

}
