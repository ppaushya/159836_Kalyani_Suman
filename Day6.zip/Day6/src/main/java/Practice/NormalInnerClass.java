package Practice;
//MainClass
public class NormalInnerClass {

	int num;
	String name;
	
	public class InnerClass
	{
		String address;
		
		/*public class Level2InnerClass
		{
			
		}*/
		public void show()
		{
			System.out.println(address);
			System.out.println(name);
			System.out.println(num);
		}
	}
}
//NormalInnerClass$InnerClass.class created