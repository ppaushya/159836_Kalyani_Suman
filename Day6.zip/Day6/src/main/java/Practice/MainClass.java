package Practice;
//NormalInnerClass
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//NormalInnerClass.InnerClass obj=new NormalInnerClass().new InnerClass();
		
		NormalInnerClass outer=new NormalInnerClass();
		NormalInnerClass.InnerClass inner=outer.new InnerClass();
		inner.show();
		//outer.show();

	}

}
