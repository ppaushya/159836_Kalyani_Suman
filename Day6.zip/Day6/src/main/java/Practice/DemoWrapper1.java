package Practice;

public class DemoWrapper1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer integer=new Integer(2);
		System.out.println(integer);
		int num=100;
		integer=num;//autoboxing
		
		System.out.println(integer);
		
		/*System.out.println(integer.MAX_VALUE);
		System.out.println(integer.MIN_VALUE);
		
		System.out.println(Short.MAX_VALUE);
		System.out.println(Short.MIN_VALUE);
		
		System.out.println(Double.MAX_VALUE);//for whole no
		System.out.println(Double.MAX_EXPONENT);//for decimal no
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MIN_NORMAL);//nothing like MAX_NORMAL
		System.out.println(Double.MIN_EXPONENT);*/
		
		String str="123";
			Integer myNum=Integer.parseInt(str);
		System.out.println(myNum);
		
		Double value=myNum.doubleValue();
		System.out.println(value);
	}

}
