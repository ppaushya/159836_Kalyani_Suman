package Practice;
//OuterClass
//Method Local Inner Class
public class MainClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OuterClass obj=new OuterClass();
		obj.details();
		//obj.print();
		//InnerClass not visible
		
	}

}
