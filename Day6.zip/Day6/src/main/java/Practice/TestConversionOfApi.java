package Practice;
import java.time.Instant;
import java.util.*;
import java.time.*;
public class TestConversionOfApi {

	public static void main(String[] args) {
		Date date=new Date();
		Instant instant=Instant.now();
		System.out.println(date);
		System.out.println(instant);
		
		Date d=Date.from(instant);
		Instant i=date.toInstant();
		
		System.out.println(d);
		System.out.println(i);
		
		//wrong
		/*LocalDate now=LocalDate.now();
		d=Date.from(now);
		LocalDate localDate=date.toLocalDate();*/
		//right
		LocalDate ld=date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		System.out.println(ld);
		
		Date d1=new Date(ld.toEpochDay());
		System.out.println(d1);
		
	}

}
