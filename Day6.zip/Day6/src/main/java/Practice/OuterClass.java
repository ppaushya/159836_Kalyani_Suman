package Practice;
//MainClass2
//Method Local Inner Class
public class OuterClass {

	String name="Jerry";
	public void details()
	{
		int count=100;
		
		class InnerClass{
			int num=45;
			String name="Jack";
			
			public void print()
			{
				OuterClass obj=new OuterClass();
				System.out.println("Num: "+num);
				System.out.println("Name: "+name);
				//System.out.println("Name: "+OuterClass.name);
				System.out.println("Name: "+obj.name);
		}
	}
		InnerClass obj1=new InnerClass();//visible inside
}
}
//OuterClass$1InnerClass.class created