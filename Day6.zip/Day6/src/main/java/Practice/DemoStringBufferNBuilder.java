package Practice;

public class DemoStringBufferNBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		StringBuffer sf=new StringBuffer("Tom");
		
		StringBuffer sf=new StringBuffer(50);//capacity=2n+2
		sf.append("Jack");
		
		System.out.println(sf);
		System.out.println(sf.length());
		System.out.println(sf.capacity());
		
		//sf.append("Jerry");
		System.out.println(sf);
		System.out.println(sf.length());
		System.out.println(sf.capacity());
		
		sf.ensureCapacity(100);//capacity is modified
		
		sf.replace(0, 3, "Jerry");
		
		//sf.append("Jerry gnhjnytjyu gtjnytghjuy t ");//increase length of buffer automatically
		System.out.println(sf);
		System.out.println(sf.length());
		System.out.println(sf.capacity());
		
		
	}

}
