package Practice;
import java.util.*;
public class TestDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d=new Date();
		System.out.println(d);
		
		Date dob=new Date(1996,01,23);//it is depricated in current API
		//1900 difference
		System.out.println(dob);
		System.out.println(dob.getTime());//print time value
		System.out.println(d.getTime());
		Date myDate=new Date(1538369723623l);
		System.out.println(myDate);
		
		System.out.println(d.after(dob));
		
		System.out.println(d.before(dob));
		
		System.out.println(d.getDate());
		System.out.println(d.getDay());
		System.out.println(d.getHours());
		System.out.println(d.getMinutes());
		System.out.println(d.getMonth());
		System.out.println(d.getSeconds());
		System.out.println(d.getYear());
		//we can modify by setter method but not add or substract date
		d.setDate(02);
		d.setHours(5);
		d.setMinutes(10);
		d.setMonth(06);
		d.setYear(2019-1900);
		d.setSeconds(15);
		System.out.println(d);
		
		
		
	}

}
