package Practice;
import java.time.format.DateTimeFormatter;
import java.util.*;
public class FormatChange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date d=new Date();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MMM-yyy");
		//System.out.println(formatter.);
	}

}
