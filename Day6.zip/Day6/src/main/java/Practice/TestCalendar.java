package Practice;
import java.util.*;
public class TestCalendar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Calendar c=new Calendar();
		//cannot create object as abstract class
		Calendar c=new GregorianCalendar();
		
		System.out.println(c.get(Calendar.DAY_OF_MONTH));
		System.out.println(c.get(Calendar.DAY_OF_WEEK));
		System.out.println(c.get(Calendar.DATE));//or c.get(5) like enum DATE has value 5
		
		Calendar today=Calendar.getInstance();//static method
		System.out.println(today);
		System.out.println(today.getTime());
		//convert calendar reference to date type
		
	    today.add(Calendar.YEAR, 3);
	    System.out.println(today.getTime());
	    
	    today.set(Calendar.YEAR, 2010);
	    System.out.println(today.getTime());
	    
	  
	    System.out.println(  today.getMinimum(Calendar.YEAR));
	    System.out.println(  today.getMaximum(Calendar.YEAR));
	    
	    System.out.println(  today.getMinimum(Calendar.MONTH));
	    System.out.println(  today.getMaximum(Calendar.MONTH));

	    System.out.println(  today.getMinimum(Calendar.DAY_OF_MONTH));
	    System.out.println(  today.getMaximum(Calendar.DAY_OF_MONTH));
	    
	    System.out.println(  today.getMinimum(Calendar.DAY_OF_WEEK));
	    System.out.println(  today.getMaximum(Calendar.DAY_OF_WEEK));

	}

}
