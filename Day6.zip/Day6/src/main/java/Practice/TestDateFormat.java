package Practice;
import java.text.*;
import java.util.*;
import java.time.*;
public class TestDateFormat {

	public static void main(String[] args) {
		DateFormat df = DateFormat.getDateInstance(0);
		//0:Monday, October 1, 2018
		//1:October 1, 2018
		//2:Oct 1, 2018
		//3:10/1/18

		     System.out.println(df.format(new Date()));
		     
		    
		 }

	}
