package Practice;

public class DemoWrapper2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer num=100;//Integer constant pool just like scp
		Integer myNum =new Integer(100);//in heap
		Integer value=100;//Integer constant pool just like scp
		Integer myValue=new Integer(100);//in heap
		
		System.out.println(num.equals(myNum));//true,compares value
		System.out.println(num==myNum);//false,compares memory
		
		System.out.println(num==value);//true
		System.out.println(num.equals(value));//true
		
		System.out.println(myNum==myValue);//false,compares memory
		System.out.println(myNum.equals(myValue));//true
	
		 
	}

}
