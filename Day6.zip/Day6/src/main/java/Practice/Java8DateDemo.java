package Practice;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjuster;
import java.time.temporal.TemporalAdjusters;

public class Java8DateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Instant instant=Instant.now();
		System.out.println(instant.now());
		
		System.out.println(instant.MIN);//-1billion
		
		System.out.println(instant.MAX);//+1billion
		
		//Duration.between(Tempo, endExclusive)
		
		LocalDate d=LocalDate.now();
		LocalTime t=LocalTime.now();
		System.out.println(d);
		System.out.println(t);

		LocalDate d2=LocalDate.of(2001, 1, 23);
		Period p=Period.between(d,d2);
		System.out.println(p.getMonths());
		System.out.println(p.getYears());
		System.out.println(p.getDays());
		System.out.println(p.isNegative());
		
		System.out.println(d.until(d2, ChronoUnit.DAYS));
		
		
		LocalDate now=LocalDate.now();
		LocalDate nextSunday=now.with(TemporalAdjusters.next(dayOfWeek.SUNDAY));
		System.out.println(nextSunday);
		
		 nextSunday=now.with(TemporalAdjusters.previous(dayOfWeek.SUNDAY));
			System.out.println(nextSunday);*/
		
		
		LocalTime now=LocalTime.now();
		System.out.println(now);
		
		LocalTime time=LocalTime.of(23,10);
		System.out.println(time);
		
		LocalTime.ofInstant(Instant.now(),ZoneId.of("GMT"));
		
		java.util.Set<String> zones=ZoneId.getAvailableZoneIds();
		for(String zone:zones)
			System.out.println(zone);
		
		
	}
	
	

}
