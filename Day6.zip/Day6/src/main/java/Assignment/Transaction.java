package Assignment;

import java.time.Instant;

public class Transaction {

	private int transId;
	private Instant transDate=Instant.now();
	private String db_cr;
	private double amount;
	private String accountType;
	private String transStmt;
}
