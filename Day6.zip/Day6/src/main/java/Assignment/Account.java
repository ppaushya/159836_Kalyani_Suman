package Assignment;
import java.time.*;
public class Account {
	private long accountNo;
	private String accountType;
	private Instant openingDate=Instant.now();
	private double openingBalance;
	

}
