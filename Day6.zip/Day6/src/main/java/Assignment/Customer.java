package Assignment;

public class Customer {

	private int customerId;
	private String name;
	
	
	private String mobileNo;
	private String emailId;
	
}
