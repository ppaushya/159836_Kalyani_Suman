package org.cap.boot;

import org.cap.model.CollectionDemo;
import org.cap.model.Employee;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestCollection {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("CollectionBean.xml");
		CollectionDemo collectionDemo=(CollectionDemo) context.getBean("myListDemo");
		CollectionDemo collectionDemo1=(CollectionDemo) context.getBean("mySetDemo");
		CollectionDemo collectionDemo2=(CollectionDemo) context.getBean("myMapDemo");
		
		System.out.println(collectionDemo);
		System.out.println(collectionDemo1);
		System.out.println(collectionDemo2);
		
		context.close();
	}

}
