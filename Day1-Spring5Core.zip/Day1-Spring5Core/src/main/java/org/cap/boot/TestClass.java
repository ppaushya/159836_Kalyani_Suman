package org.cap.boot;

import org.cap.model.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("myBeans.xml");
		Employee employee=(Employee) context.getBean("emp");
		//Employee employee1=(Employee) context.getBean("emp");
		
		//employee.setEmployeeName("Jerry");
		
		System.out.println(employee);
		//System.out.println(employee1);
		context.close();
	}

}
