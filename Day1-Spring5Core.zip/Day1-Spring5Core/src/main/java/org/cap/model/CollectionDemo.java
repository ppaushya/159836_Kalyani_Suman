package org.cap.model;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class CollectionDemo {

	private List<String> names;
	private Set<String> nameSet;
	private Map addressMap;
	private Properties addressProps;

	public CollectionDemo() {}
	
	public CollectionDemo(List<String> names) {
		super();
		this.names = names;
	}

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	
	public Set<String> getNameSet() {
		return nameSet;
	}

	public void setNameSet(Set<String> nameSet) {
		this.nameSet = nameSet;
	}

	public Map getAddressMap() {
		return addressMap;
	}

	public void setAddressMap(Map addressMap) {
		this.addressMap = addressMap;
	}

	public Properties getAddressProps() {
		return addressProps;
	}

	public void setAddressProps(Properties addressProps) {
		this.addressProps = addressProps;
	}

	@Override
	public String toString() {
		return "CollectionDemo [names=" + names + ", nameSet=" + nameSet + ", addressMap=" + addressMap
				+ ", addressProps=" + addressProps + "]";
	}
	
	
}
