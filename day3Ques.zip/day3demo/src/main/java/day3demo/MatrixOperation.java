package day3demo;

import java.util.Scanner;

public class MatrixOperation {

	Scanner sc=new Scanner(System.in);
	int row,col;
	public void getSize()
	{
		System.out.println("Enter num of row and col: ");
		row=sc.nextInt();
		col=sc.nextInt();
		
	}
	public void getElem(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
	}
	public void print(int[][] arr)
	{
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
	public int[][] add(int[][] arr1,int[][] arr2)
	{
		int[][] sum=new int[row][col];
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<col;j++)
			{
				sum[i][j]=arr1[i][j]+arr2[i][j];
			}
		}
		return sum;
	}
	public int[][] multiply(int[][] arr1,int[][] arr2)
	{
		int[][] prod=new int[row][col];
		for (int c = 0; c < p; c++)
		      for (int d = 0; d < q; d++)
		        scanf("%d", &second[c][d]);
		 
		    for (int c = 0; c < m; c++) {
		      for (d = 0; d < q; d++) {
		        for (k = 0; k < p; k++) {
		          sum = sum + first[c][k]*second[k][d];
		        }
		 
		        multiply[c][d] = sum;
		        sum = 0;
		      }
		    }
		return prod;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		MatrixOperation obj=new MatrixOperation();
		
		System.out.println("Enter info for Matrix1:");
		obj.getSize();
		int[][] arr1=new int[obj.row][obj.col];
		obj.getElem(arr1);
		obj.print(arr1);
		
		System.out.println("Enter info for Matrix2:");
		obj.getSize();
		int[][] arr2=new int[obj.row][obj.col];
		obj.getElem(arr2);
		obj.print(arr2);
		
		
		int[][] sum=obj.add(arr1,arr2);
		obj.print(sum);
		//int[][] prod=obj.multiply(arr1,arr2);
		//obj.print(prod);
		sc.close();
		
	}

}
