package day3demo;

import java.util.Scanner;

public class Employee {
	Scanner sc=new Scanner(System.in);
	int id;
	String fname;
	String lname;
	int age;
	int salary;
	public void getDetails()
	{
		/*System.out.println("Enter ID: ");
		id=sc.nextInt();*/
		System.out.println("Enter first name: ");
		fname=sc.nextLine();
		System.out.println("Enter last name: ");
		lname=sc.nextLine();
		System.out.println("Enter age: ");
		age=sc.nextInt();
		System.out.println("Enter salary: ");
		salary=sc.nextInt();
	}
	public void printDetails()
	{
//		System.out.print("Id: "+id+"\t");
		System.out.print("First name: "+fname+"\t");
		System.out.print("Last name: "+lname+"\t");
		System.out.print("Age: "+age+"\t");
		System.out.print("Salary: "+salary+"\t\n");
		
	}
	public static void sortEmp(Employee[] emp)
	{
		Employee temp=new Employee();
		for(int i=0;i<emp.length;i++)
		{
			for(int j=i+1;j<emp.length;j++)
			{
				if(emp[i].age>emp[j].age)
				{
					/*temp.id=emp[i].id;
					emp[i].id=emp[j].id;
					emp[j].id=temp.id;*/
					
					temp.fname=emp[i].fname;
					emp[i].fname=emp[j].fname;
					emp[j].fname=temp.fname;
					
					temp.lname=emp[i].lname;
					emp[i].lname=emp[j].lname;
					emp[j].lname=temp.lname;
					
					temp.age=emp[i].age;
					emp[i].age=emp[j].age;
					emp[j].age=temp.age;
					
					temp.salary=emp[i].salary;
					emp[i].salary=emp[j].salary;
					emp[j].salary=temp.salary;
				}
			}
				
		}
	}
public static void main(String[] args) {
		
	
		Employee[] emp=new Employee[2];
		for(int i=0;i<emp.length;i++)
		{
			
			emp[i]=new Employee();
			
		}
		for(int i=0;i<emp.length;i++)
		{
			
			emp[i].getDetails();
		}
		
		System.out.println("The employee details are: ");
		for(int i=0;i<emp.length;i++)
		{
			emp[i].printDetails();
		}
		System.out.println("After sorting: ");
		Employee.sortEmp(emp);//passing array of object in method
		for(int i=0;i<emp.length;i++)
		{
			emp[i].printDetails();
		}
		
		
	}
}
