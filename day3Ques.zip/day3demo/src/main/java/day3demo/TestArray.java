package day3demo;

public class TestArray {

	public static void main(String[] args) {
		
		int[] arr=new int[10];//declaration
		
		short mynum=90;
		float pi=3.14f;
		arr[0]=1;
		arr[1]=mynum;
		arr[2]=78;
		
		arr[7]=98;
		arr[8]=(int)pi;
		
		//System.out.println(arr);
		for(int i=0;i<10;i++)
			System.out.println(arr[i]);
		
	}

}
