package day3demo;

public class TestVararg {
	
	public void printData(int ... arr)//vararg should be the last argument
	{//no two vararg together
		for(int value: arr)
		{
			System.out.print(value+" ");
		}
	}
	public static void main(String[] args) {

		int[] num1= {1,2,3,4};
		TestVararg obj=new TestVararg();
		obj.printData(num1);
	}

}
