package org.cap.boot;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Employee;

public class MainClass {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		/*Employee employee=new Employee("Kalyani","Suman",30000,"kal@gmail.com",new Date(),"kal123");
		Employee employee1=new Employee("tom","thomson",32000,"tom@gmail.com",new Date(),"tom123");
		Employee employee2=new Employee("Jerry","Jack",40000,"jj@gmail.com",new Date(),"jj123");
		 
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);*/
		
		//read
		Employee employee=entityManager.find(Employee.class, 1);
		System.out.println(employee);
		
		//remove
		Employee employee1=entityManager.find(Employee.class, 2);
		//entityManager.remove(employee1);
		
		//update
		Employee employee2=entityManager.find(Employee.class, 3);
		employee2.setSalary(34000);
		
		transaction.commit();

	}
	

}
