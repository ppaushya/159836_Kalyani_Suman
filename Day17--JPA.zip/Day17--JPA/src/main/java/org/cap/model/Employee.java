package org.cap.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="employee_info")
public class Employee {
	
	@Id
	@GeneratedValue
	private int empId;
	
	@Column(nullable=false)
	private String firstName;
	private String lastName;
	private double salary;
	
	@Column(name="empEmail", unique=true)
	private String emailId;
	
	@Temporal(value=TemporalType.DATE)
	private Date dateOfJoining;
	@Transient
	private String empPassword;
	
	public String getEmailId() {
		return emailId;
	}

	
	public Employee(String firstName, String lastName, double salary, String emailId, Date dateOfJoining,
			String empPassword) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.empPassword = empPassword;
	}


	public Employee(int empId, String firstName, String lastName, double salary, String emailId, Date dateOfJoining,
			String empPassword) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.empPassword = empPassword;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public Employee() {
		
	}
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}


	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", emailId=" + emailId + ", dateOfJoining=" + dateOfJoining + ", empPassword=" + empPassword + "]";
	}

	
}
