
public class Employee {

	int empId;
	String empName;
	int age;
	int salary;
	Weekdaays weekOff;
	
	public void getEmployee()
	{
		empId=1001;
		empName="tom";
		age=25;
		salary=5500;
		weekOff=Weekdaays.SAT;
		
	}
	public void printEmployee()
	{
		System.out.println(empId+"-"+empName+"-"+age+"-"+salary+"-"+weekOff.getValue());
	}
	public static void main(String[] args) {

		Employee emp=new Employee();
		emp.getEmployee();
		emp.printEmployee();
		
		
		Weekdaays[] values=Weekdaays.values();
		for(Weekdaays day : values)
		{
			System.out.println(day);
		}
		
		String str="TUE";//case sensitive
		Weekdaays yourday=Weekdaays.valueOf(Weekdaays.class,str);
		//check if str is present or not
		//if present then return the data
		//if str not found then exception
		System.out.println(yourday);
	}

}
