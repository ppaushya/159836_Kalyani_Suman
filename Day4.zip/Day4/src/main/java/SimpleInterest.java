//method overloading
public class SimpleInterest {
	int p;
	int roi;
	int time;
	public SimpleInterest(int p, int roi) {

		this.p = p;
		this.roi = roi;
	
	}
	public SimpleInterest(int p, int roi, int time) {
		
		this(p,time);//manually invoke constructor
		//can be in first line only
	
		//this.p = p;
		this.roi = roi;
		//this.time = time;
	}
	
	
	public float calculate()
	{
		System.out.println("In method with no argument");
		return (p*roi*time)/100;
	}
	public float calculate(int p)
	{
		System.out.println("In method with one argument");
		return (p*this.roi*this.time)/100;//this not mandatory
	}
	public float calculate(int p,int roi)
	{
		System.out.println("In method with two argument");
		return (p*roi*time)/100;
	}
	public float calculate(int p,int roi,int time)
	{
		
		System.out.println("In method with three argument");
		return (p*roi*time)/100;
	}
	

	public static void main(String[] args) {
		SimpleInterest obj=new SimpleInterest(5000,12,5);
		
		float si=obj.calculate();
		System.out.println("SI= "+si);
		
		
		si=obj.calculate(6000);
		System.out.println("SI= "+si);
		
		
		si=obj.calculate(6000,15);
		System.out.println("SI= "+si);
		
		
		si=obj.calculate(6000,15,3);
		System.out.println("SI= "+si);
	}

}
