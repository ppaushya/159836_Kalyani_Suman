import java.util.*;
public class TestClass {

	public static void main(String[] args) {

		/*String[] str= {"abc","xyz","tom","jack"};
		for(int i=0;i<str.length;i++)
			System.out.print(str[i]+" ");
		Arrays.sort(str);
		System.out.println();
		for(int i=0;i<str.length;i++)
			System.out.print(str[i]+" ");*/
		
		int[] myArr= {11,25,3,15,73,34,8};
		int[] arr =Arrays.copyOf(myArr, 3);
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");
		
		System.out.println();
		
		for(int i=0;i<myArr.length;i++)
			System.out.print(myArr[i]+" ");
		
		System.out.println();
		Arrays.sort(myArr);
		int result=Arrays.binarySearch(myArr,73);
		System.out.println(result);
		
		
	}

}
