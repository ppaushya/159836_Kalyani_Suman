
public class TestString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="Tom";
		String mystr=new String("Jack");
		
		String str1="Tom";
		String mystr1=new String("Jack");
		
		System.out.println(str);
		System.out.println(str.hashCode());//confirmation that object is created
		
		
		System.out.println(str1);
		System.out.println(str1.hashCode());
		
		System.out.println(mystr);
		System.out.println(mystr.hashCode());
		//hashCode is creating bucketing address
		
		System.out.println(mystr1);
		System.out.println(mystr1.hashCode());
		
	}

}
