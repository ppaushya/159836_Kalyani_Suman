package com.cap.validate;

public class Validation {

	int count=100;
	public static int num=1001;
	
	public void demo()
	{
		
		System.out.println("This is instance member");
		System.out.println("Number: "+num);
		System.out.println("Count: "+count);
	}
	public static void show() {

		System.out.println("Static member");
		System.out.println("Number: "+num);
		//System.out.println("Count: "+count);compile time error
	}

}
