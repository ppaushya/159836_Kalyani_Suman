
public class StringMethod {

	public static void main(String[] args) {
		String str1="abcdefg";
		String str2="xyzjkl";
		String str3="Abcdefg";
		System.out.println("charAt "+str1.charAt(4));
		System.out.println("codePointAt "+str1.codePointAt(3));
		if(str1.compareTo(str2)<1)
		{
			System.out.println("str1 comes first in lexicography order");
			
		}
		if(str1.compareToIgnoreCase(str3)==0)
		{
			System.out.println("Ignore case difference");
			
		}
		
		System.out.println(str3.concat(str2));
		if(str1.contains("abc"))
			System.out.println("char Sequence is present");
		if(str1.contentEquals("abcdefg"))
			System.out.println("char Sequence is same as string");
		char[] data= {'q','w','e','r','t','y'};
		 str3=str3.copyValueOf(data);
		System.out.println(str3);
		str3=str3.copyValueOf( data, 2,  3);
		System.out.println(str3);
		if(str1.endsWith("efg"))
			System.out.println(str1+" ends with efg ");
		
		System.out.println(str1.equals(str2));
		
		System.out.println(str1.equalsIgnoreCase("Abcdefg"));
		
		/*static String
		format(Locale l, String format, Object... args)
		Returns a formatted string using the specified locale, format string, and arguments.
		static String
		format(String format, Object... args)
		Returns a formatted string using the specified format string and arguments.*/

		//System.out.println(str1.getBytes("UTF-16"));
		
		
		
	}

}
