
//import com.cap.validate.Validation.*;
import static com.cap.validate.Validation.*;

public class TestValidation {

	public static void main(String[] args) {
		
		/*Validation obj=new Validation();
		obj.demo();
		obj.show();//can be accessed as validation.show()
		System.out.println("Num: "+ obj.num);//can be accessed as validation.num
		System.out.println("Count: "+ obj.Count);*/
		
		show();
		System.out.println("Num: "+ num);
		
	}

}
