import java.util.*;
public class MainClass {

	Scanner sc=new Scanner(System.in);
	public Weekdaays myday;
	public int getChoice()
	{
		
		System.out.println("Enter choice between 1-7");
		int choice=sc.nextInt();
		return choice;
	}
	public void getDay(int choice)
	{
		switch(choice)
		{
		case 1:
			myday=Weekdaays.SUN;
			break;
		case 2:
			myday=Weekdaays.MON;break;
		case 3:
			myday=Weekdaays.TUE;break;
		case 4:
			myday=Weekdaays.WED;break;
		case 5:
			myday=Weekdaays.THUR;break;
		case 6:
			myday=Weekdaays.FRI;break;
		case 7:
			myday=Weekdaays.SAT;break;
			
		}
	}
	public void printDay()
	{
		System.out.println("You hav entered "+myday+".");
	}
	
	public static void main(String[] args) {
		MainClass obj=new MainClass();
		int choice=obj.getChoice();
		obj.getDay(choice);
		obj.printDay();
		
	}

}
