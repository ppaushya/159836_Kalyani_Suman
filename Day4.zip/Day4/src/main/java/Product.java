//constructors
//constructor overloading
public class Product {

	
	int productId;
	String productName;
	double price;
	int qty;
	
	
	public Product()
	{
		System.out.println("This is default constructor");
	}
	
	public Product(int pId)
	{
		System.out.println("Overload constructor with 1 argument");
		this.productId=pId;
	}
	//using source
	public Product(int productId, String productName) {
		//super();
		this.productId = productId;
		this.productName = productName;
	}

	public Product(int pId,String pName,double price,int qty)
	{
		System.out.println("Overload constructor with many argument");
		this.productId=pId;
		this.productName=pName;
		this.price=price;
		this.qty=qty;
		
	}
	
	//API implementation
	//along with hexadec info contains data member info
	//instead of hexadec, it shows data member info
	//method of Object class
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + ", qty=" + qty
				+ "]";
	}

	public void printProduct()
	{
		System.out.println("product name: "+productId+"Product Name: "+productName+"\nPrice: "+price+"Quantity: "+qty);
	}
	public static void main(String[] args) {

		Product p1=new Product();//calling of default constructor
		System.out.println(p1);
		Product p2=new Product(111);
		System.out.println(p2);
		p2.printProduct();
		
		Product p3=new Product(111,"abc",5000,2);
		System.out.println(p3);
		p3.printProduct();
		
		
		//create diff memory for same data but for String object it refer to same memory space
		/*Product p4=new Product(111,"abc",5000,2);
		System.out.println(p4.hashCode());
		
		Product p5=new Product(111,"abc",5000,2);
		System.out.println(p5.hashCode());*/

	}

}
