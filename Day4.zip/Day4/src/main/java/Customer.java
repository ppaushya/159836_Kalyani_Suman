
enum CustomerType{
	SILVER(0,100),GOLD(101,200),DIAMOND(201,300),PLATINUM(301,400);
	
	int minrewardPoints;
	int maxrewardPoints;
	
	private CustomerType(int minrewardPoints,int maxrewardPoints)
	{
		this.minrewardPoints=minrewardPoints;
		this.maxrewardPoints=maxrewardPoints;
	}
	
	public int getMinValue()
	{
		return this.minrewardPoints;
	}
	
	public int getMaxValue()
	{
		return this.maxrewardPoints;
	}
}

public class Customer {

	int cId=1001;
	String cName="Jack";
	CustomerType cType=CustomerType.DIAMOND;
	
	public static void main(String[] args) {

		Customer c=new Customer();
		System.out.println(c.cId+"-"+c.cName+"-"+c.cType+"-"+c.cType.getMinValue()+"-"+c.cType.getMaxValue());

	}

}
