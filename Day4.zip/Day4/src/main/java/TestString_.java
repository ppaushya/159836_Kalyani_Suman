
public class TestString_ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="Tom";
		String mystr=new String("Tom");
		String str1="Tom";
		String mystr1=new String("Tom");
		
		System.out.println(str==mystr);//compare memory location scp for str and heap for mystr 
		System.out.println(str.equals(mystr));
		
		System.out.println(str==str1);//they r pointing to same memory space
		
		System.out.println(str.equals(str1));
		System.out.println(mystr==mystr1);//bcoz they r pointing to different memory space in heap
		//new object created
	}

}
