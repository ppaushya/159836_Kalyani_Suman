
public class StringArgs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		if(args.length>0)
		{
			int sum=0;
			int num=0;
			for(String str : args)
			{
				System.out.println(str);
				num=Integer.parseInt(str);//wrapper class
				sum=sum+num;
			}
			System.out.println(sum);
		}
	}

}
