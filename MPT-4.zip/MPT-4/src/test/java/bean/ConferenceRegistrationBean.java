package bean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationBean {

	
	private String title;
	private String heading;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	@FindBy(name="txtLN")
	private WebElement lastName;
	@FindBy(name="txtEmail")
	private WebElement email;
	@FindBy(name="txtPhone")
	private WebElement phone;
	
	@FindBy(name="size")
	private Select peopleAttending;
	
	@FindBy(name="Address")
	private WebElement address1;
	@FindBy(name="Address2")
	private WebElement address2;
	@FindBy(name="city")
	private Select city;
	@FindBy(name="state")
	private Select state;
	@FindBy(name="memberStatus")
	private WebElement isMember;
	
	private WebDriver driver;
	
	public ConferenceRegistrationBean() {
		
	}

	public ConferenceRegistrationBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}

	public String getTitle() {
		return driver.getTitle();
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getHeading() {
		return driver.findElement(By.tagName("h2")).getText();
	}

	public void setHeading(String heading) {
		this.heading = heading;
	}

	public String getFirstName() {
		return firstName.getText();
	}

	public void setFirstName(String firstName) {
		
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getText();
	}

	public void setLastName(String lastName) {
		
		this.lastName.sendKeys(lastName);;
	}

	public String getEmail() {
		return email.getText();
	}

	public void setEmail(String email) {
		
		this.email.sendKeys(email);;
	}

	public String getPhone() {
		return phone.getText();
	}

	public void setPhone(String phone) {
		driver.findElement(By.name("Phone")).sendKeys(phone);
		this.phone.sendKeys(phone);;
	}

	public WebElement getPeopleAttending() {
		return peopleAttending.getFirstSelectedOption();
	}


	public void setPeopleAttending(int peopleAttending2) {
		
		this.peopleAttending.selectByIndex(peopleAttending2);
	}
	
	public String getAddress1() {
		return address1.getText();
	}

	public void setAddress1(String address1) {
		
		this.address1.sendKeys(address1);;
	}

	public String getAddress2() {
		return address2.getText();
	}

	public void setAddress2(String address2) {
		
		this.address2.sendKeys(address2);;
	}

	public WebElement getCity() {
		return city.getFirstSelectedOption();
	}

	public void setCity(String city) {
		
		this.city.getFirstSelectedOption();
	}

	public WebElement getState() {
		return state.getFirstSelectedOption();
	}

	public void setState(String state) {
		
		this.state.getAllSelectedOptions();
	}

	public String getIsMember() {
		return isMember.getText();
	}

	public void setIsMember(boolean isMember) {
		
		this.isMember.findElement(By.name("memberStatus"));
	}

	public void onClick_navigate_to_mainPage() {
		
		driver.findElement(By.partialLinkText("Next")).click();
		
		
	}

	
	
}
