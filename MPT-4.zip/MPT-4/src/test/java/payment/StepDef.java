package payment;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webdriver;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","E:\\\\capgTraining\\\\java prog\\\\chromedriver.exe");
		webdriver= new ChromeDriver();
	}
	
	@Given("^user details$")
	public void user_details() throws Throwable {
		webdriver.get("file:///E:/capgTraining/TopUp/Conferencebooking/PaymentDetails.html");
	}

	@When("^all fields are valid$")
	public void all_fields_are_valid() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Tom");
		webdriver.findElement(By.name("debit")).sendKeys("Cat");
		webdriver.findElement(By.id("txtCvv")).sendKeys("789");
		webdriver.findElement(By.id("txtMonth")).sendKeys("11");
		webdriver.findElement(By.id("txtYear")).sendKeys("2018");
	}

	@Then("^display 'Registration Successful' in alert box$")
	public void display_Registration_Successful_in_alert_box() throws Throwable {
		webdriver.findElement(By.id("btnPayment")).click();
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Conference Room Booking successfully done!!!", alertFN);
		webdriver.switchTo().alert().accept();
	}
	
	@After
	public void tearDown() {
		
		webdriver.quit();
		
	}

}
