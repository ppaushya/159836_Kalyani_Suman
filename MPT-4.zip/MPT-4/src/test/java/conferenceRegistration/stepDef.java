package conferenceRegistration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import bean.ConferenceRegistrationBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {

	private ConferenceRegistrationBean conferenceRegistrationBean;
	
	private WebDriver webdriver;
	
	private String title,heading;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\kalsuman\\Downloads\\chromedriver.exe");
		webdriver= new ChromeDriver();
		conferenceRegistrationBean=new ConferenceRegistrationBean(webdriver);
		
	}

	@Given("^conference registration page$")
	public void conference_registration_page() throws Throwable {
		webdriver.navigate().to("file:///C:/Users/kalsuman/Desktop/Conferencebooking/ConferenceRegistartion.html");
		//Thread.sleep(1000);
	}

	@When("^title is not 'Conference Registration'$")
	public void title_is_not_Conference_Registration() throws Throwable {
		
		assertNotEquals("Conference Registration", conferenceRegistrationBean.getTitle());
		//Thread.sleep(1000);
	}

	@Then("^quit test$")
	public void quit_test() throws Throwable {
		webdriver.quit();
	}

	@When("^heading is not 'Personal Details'$")
	public void heading_is_not_Personal_Details() throws Throwable {
		
		assertNotEquals("Personal Details", conferenceRegistrationBean.getHeading());
		//Thread.sleep(1000);
	}

	@When("^first name is null and next is clicked$")
	public void first_name_is_null_and_next_is_clicked() throws Throwable {
		
		conferenceRegistrationBean.setFirstName("");
		//Thread.sleep(1000);
		
		conferenceRegistrationBean.onClick_navigate_to_mainPage();
		//Thread.sleep(1000);
	}

	@Then("^alert box displays 'Please fill the First Name'$")
	public void alert_box_displays_Please_fill_the_First_Name() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the First Name", alertFN);
		if(alertFN.equals("Please fill the First Name"))
			System.out.println("true");
		else System.out.println("false");
		Thread.sleep(1000);
	}

	@When("^last name is null and next is clicked$")
	public void last_name_is_null_and_next_is_clicked() throws Throwable {
		conferenceRegistrationBean.setFirstName("Tom");
		Thread.sleep(1000);
		conferenceRegistrationBean.setLastName("");
		conferenceRegistrationBean.onClick_navigate_to_mainPage();
	}

	@Then("^alert box displays 'Please fill the Last Name'$")
	public void alert_box_displays_Please_fill_the_Last_Name() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Last Name", alertFN);
		if(alertFN.equals("Please fill the Last Name"))
			System.out.println("true");
		else System.out.println("false");
		//Thread.sleep(1000);
	}

	@When("^email is null and next is clicked$")
	public void email_is_null_and_next_is_clicked() throws Throwable {
		conferenceRegistrationBean.setFirstName("Tom");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setLastName("Jerry");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setEmail("");
		//Thread.sleep(1000);
		conferenceRegistrationBean.onClick_navigate_to_mainPage();
	}

	@Then("^alert box displays 'Please fill the Email'$")
	public void alert_box_displays_Please_fill_the_Email() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Email", alertFN);
		if(alertFN.equals("Please fill the Email"))
			System.out.println("true");
		else System.out.println("false");
		Thread.sleep(1000);
	}

	@When("^contact no\\. is null and next is clicked$")
	public void contact_no_is_null_and_next_is_clicked() throws Throwable {
		conferenceRegistrationBean.setFirstName("Tom");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setLastName("Jerry");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setEmail("tom@gmail.com");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setPhone("");
		//Thread.sleep(1000);
		conferenceRegistrationBean.onClick_navigate_to_mainPage();
	}

	@Then("^alert box displays 'Please fill the Contact No\\.'$")
	public void alert_box_displays_Please_fill_the_Contact_No() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Contact No.", alertFN);
		if(alertFN.equals("Please fill the Contact No."))
			System.out.println("true");
		else System.out.println("false");
		Thread.sleep(1000);
	}

	@When("^contact no\\. does not match pattern and next is clicked$")
	public void contact_no_does_not_match_pattern_and_next_is_clicked() throws Throwable {
		conferenceRegistrationBean.setFirstName("Tom");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setLastName("Jerry");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setEmail("tom@gmail.com");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setPhone("987456321");
		Thread.sleep(1000);
		conferenceRegistrationBean.onClick_navigate_to_mainPage();
	}

	@Then("^alert box displays 'Please enter valid Contact no\\.'$")
	public void alert_box_displays_Please_enter_valid_Contact_no() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please enter valid Contact no.", alertFN);
		if(alertFN.equals("Please enter valid Contact no."))
			System.out.println("true");
		else System.out.println("false");
		//Thread.sleep(1000);
	}

	@When("^Number of people attending is not selected and next is clicked$")
	public void number_of_people_attending_is_not_selected_and_next_is_clicked() throws Throwable {		
		conferenceRegistrationBean.setFirstName("Tom");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setLastName("Jerry");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setEmail("tom@gmail.com");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setPhone("9874563210");
		Thread.sleep(1000);
		//conferenceRegistrationBean.setPeopleAttending();
		//Thread.sleep(1000);
		//select.deselectAll();
		conferenceRegistrationBean.onClick_navigate_to_mainPage();
	}

	@Then("^alert box displays 'Number of people attending'$")
	public void alert_box_displays_Number_of_people_attending() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Number of people attending", alertFN);
		if(alertFN.equals("Please fill the Number of people attending"))
			System.out.println("true");
		else System.out.println("false");
		//Thread.sleep(1000);
	}

	@When("^valid details given and next is clicked$")
	public void valid_details_given_and_next_is_clicked() throws Throwable {
		conferenceRegistrationBean.setFirstName("Tom");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setLastName("Jerry");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setEmail("tom@gmail.com");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setPhone("9874563210");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setPeopleAttending(2);
		//Thread.sleep(1000);
		conferenceRegistrationBean.setAddress1("MIPL");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setAddress2("Mahindra World City");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setCity("Chennai");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setState("Tamilnadu");
		//Thread.sleep(1000);
		conferenceRegistrationBean.setIsMember(true);
		Thread.sleep(1000);
		conferenceRegistrationBean.onClick_navigate_to_mainPage();
	}

	@Then("^alert box displays 'Personal details are validated'$")
	public void alert_box_displays_Personal_details_are_validated() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Personal details are validated.", alertFN);
		webdriver.switchTo().alert().accept();
		//Thread.sleep(1000);
		webdriver.navigate().to("file:///C:/Users/kalsuman/Desktop/Conferencebooking/PaymentDetails.html");
		//Thread.sleep(1000);
	}
	
	@After
	public void tearDown() {
		
		webdriver.quit();
		
	}
	

}
