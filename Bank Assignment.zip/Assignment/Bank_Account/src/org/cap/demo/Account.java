package org.cap.demo;

import java.util.Date;
import java.util.Scanner;

public class Account extends Customer {
	
	private long accountNo;
	private String accountType;
	private String openingDate;
	 double openingBalance;
	 int type;
	
	
	Scanner KB=new Scanner(System.in);
	

	public void openAccount()
	{ 
		System.out.print("Enter Account Number: ");
		accountNo=KB.nextLong();
		System.out.print("Enter Account Type: ");
		System.out.println("Enter 1. Saving\t2. Current\t3. FD\t4. RD");
        type=KB.nextInt();
         switch(type)
                 {
                     case 1:
                         accountType="Saving";
                     break;
                     case 2:
                         accountType="Current";
                     break;
                     case 3:
                         accountType="FD";
                     break;
                     case 4:
                         accountType="RD";
                     break;
                     default:
                         System.out.println("Not a valid input");
                 }
		System.out.print("Enter Opening Date: ");
		openingDate=KB.next();
		System.out.print("Enter Opening Balance: ");
		openingBalance =KB.nextDouble();
	}
	
	void showAccount()
	{ 
		System.out.print(accountNo);
		System.out.println(accountType);
		System.out.println(openingDate);
		System.out.println(openingBalance);
	}


	//method to search an account number
	boolean search(Long acn)
	{ 
		if(accountNo == acn)
		{ 
			showAccount();
			return(true);
		}
		return(false);
	}


  
	}