package org.cap.demo;

import java.util.Date;

import java.util.Scanner;

 public class Transaction extends Account{
	 
	 public void getCust()
	 {
		 getCustomer();
		 openAccount();
	 }
	
      public static void main(String[] args) {
    	  	int userChoice;
    	  	int CustId;
    	  	boolean quit = false;
    	  	
            Scanner in = new Scanner(System.in);
            
    	  	System.out.println("Welcome to the greatest Bank you ever met");
    	  	
    	  	System.out.print("How Many Customer U Want to Input : ");
    		int n=in.nextInt();
    		int found=0;
    		Transaction  C[]=new Transaction[n];
    		for(int i=0;i<C.length;i++)
    		{   
    			C[i]=new Transaction();
    			C[i].getCust();
    		}
    	  	System.out.print("Enter Customer Id: ");
    		CustId=in.nextInt();
    		for(int i=0;i<C.length;i++)
    		{
	    		if(CustId==C[i].customerId)
	    	  	{
			
			            do {
			
			                  System.out.println("1. Deposit money");
			
			                  System.out.println("2. Withdraw money");
			
			                  System.out.println("3. Check balance");
			
			                  System.out.print("Your choice, 0 to quit: ");
			
			                  userChoice = in.nextInt();
			
			                  switch (userChoice) {
			
			                  case 1:
			
			                        float amount;
			
			                        System.out.print("Amount to deposit: ");
			
			                        amount = in.nextFloat();
			
			                        if (amount <= 0)
			
			                             System.out.println("Can't deposit nonpositive amount.");
			
			                        else {
			
			                             C[i].openingBalance += amount;
			
			                             System.out.println("$" + amount + " has been deposited.");
			
			                        }
			
			                        break;
			
			                  case 2:
			
			                        System.out.print("Amount to withdraw: ");
			
			                        amount = in.nextFloat();
			
			                        if (amount <= 0 || amount >  C[i].openingBalance)
			
			                             System.out.println("Withdrawal can't be completed.");
			
			                        else {
			
			                        	 C[i].openingBalance -= amount;
			
			                             System.out.println("$" + amount + " has been withdrawn.");
			
			                        }
			
			                        break;
			
			                  case 3:
			
			                        System.out.println("Your balance: $" +  C[i].openingBalance);
			
			                        break;
			
			                  case 0:
			
			                        quit = true;
			
			                        break;
			
			                  default:
			
			                        System.out.println("Wrong choice.");
			
			                        break;
			
			                  }
			
			                  System.out.println();
			
			            } while (!quit);
			
			            System.out.println("Bye!");
			            found = found+1;
			
			      }
	    		if(found == 1)
	    		{
	    			System.exit(0);
	    		}
	    		else
	    		{
	    			System.out.println("You have to sign up for opening a account");
	    			C[n+1].getCust();
	    		}
    		}
    	
    		
      }

}
