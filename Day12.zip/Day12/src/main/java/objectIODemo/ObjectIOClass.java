package objectIODemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class ObjectIOClass {

	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {

		File file=new File("D:\\Users\\kalsuman\\Desktop\\Module2\\ExampleFile\\product.txt");
		try(FileOutputStream out=new FileOutputStream(file);
				ObjectOutputStream outputStream=new ObjectOutputStream(out))
		{
			Product product=new Product();
			String choice;
			do
			{
				product=userInteraction.getDetails();
			outputStream.writeObject(product);
			System.out.println("Enter choice[y|n]: ");
			choice=scanner.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();

		}catch(IOException e )
		{
			e.printStackTrace();

		}
		
		
		try(FileInputStream in=new FileInputStream(file);
				ObjectInputStream inputStream=new ObjectInputStream(in))
		{
			Product product1=(Product) inputStream.readObject();
			while(product1!=null)
			 {
				System.out.println(product1);
				product1=(Product) inputStream.readObject();
			 
			 }
			
			
		}catch(FileNotFoundException e)
		{
			e.printStackTrace();

		}catch(IOException e )
		{
			e.printStackTrace();

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
