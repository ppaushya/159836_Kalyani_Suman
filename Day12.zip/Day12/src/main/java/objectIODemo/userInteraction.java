package objectIODemo;

import java.time.LocalDate;
import java.util.Scanner;

public class userInteraction {

	static Scanner scanner=new Scanner(System.in);
	
	public static Product getDetails() {
		
		Product p=new Product();
		System.out.println("Enter product id: ");
		p.setProductId(scanner.nextInt());
		System.out.println("Enter product name: ");
		p.setProductName(scanner.next());
		System.out.println("Enter Quantity: ");
		p.setQuantity(scanner.nextInt());
		System.out.println("Enter Price: ");
		p.setPrice(scanner.nextDouble());
		p.setExpiryDate(LocalDate.now());
		
		return p;
	}

}
