package FilePractice;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadReverse {

	public static void main(String[] args) throws IOException {
		int ch;
		File file=new File("D:\\Users\\kalsuman\\Desktop\\Module2\\ExampleFile\\mydemo.txt");
		int[] reverse = new int[100];
		int i,n=0;
		try (FileReader reader=new FileReader(file))
		{
			
			do {
			ch=reader.read();
			reverse[n]=ch;
			n++;
			}
			while(ch!='\0');
			for(i=reverse.length;i>=0;i--)
			{
				System.out.println(reverse[i]);
			}
		} catch (FileNotFoundException  e) {

			e.printStackTrace();
		}

	}

}
