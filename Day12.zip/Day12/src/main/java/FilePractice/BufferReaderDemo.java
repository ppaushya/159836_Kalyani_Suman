package FilePractice;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;

public class BufferReaderDemo {

	public static void main(String[] args) {

		File file=new File("D:\\Users\\kalsuman\\Desktop\\Module2\\ExampleFile\\mydemo.txt");
		try(FileInputStream in=new FileInputStream(file);
				BufferedInputStream input=new BufferedInputStream(in)) {
			
			int myBite=BufferedReader reader=new BufferedReader(in);
		}catch(FileNotFoundException e) {
			
		}
		

	}

}
