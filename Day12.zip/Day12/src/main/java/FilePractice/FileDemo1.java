package FilePractice;

import java.io.File;
import java.io.IOException;

public class FileDemo1 {

	public static void main(String[] args) throws IOException {

		File file=new File("D:\\Users\\kalsuman\\Desktop\\Module2\\ExampleFile\\mydemo.txt");
//		FIle file=new FIle("name.txt");
//		file.delete();
		if(file.isFile())
		{
			if(file.exists())
			{
				System.out.println("Readable: "+file.canRead());
				System.out.println("Writable: "+file.canWrite());
				System.out.println("Executable: "+file.canExecute());
				System.out.println("path: "+file.getAbsolutePath());
				
			}
			else
			{
				System.out.println("File does not exists");
				
			}
		}else if(file.isDirectory()) {
			String[] names=file.list();
			System.out.println(names);
		}else{
			System.out.println("Directory does not exists");
			file.createNewFile();//throws exception
		}
		
		

	}

}
