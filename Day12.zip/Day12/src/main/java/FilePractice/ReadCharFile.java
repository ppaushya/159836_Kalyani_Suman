package FilePractice;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadCharFile {

	public static void main(String[] args) throws IOException {

		//open the file and cursor will be open for read mode
		int ch;
		File file=new File("D:\\Users\\kalsuman\\Desktop\\Module2\\ExampleFile\\mydemo.txt");
		try (FileReader reader=new FileReader(file))//close resource
		{
			
			do {
			ch=reader.read();
			System.out.print((char)ch);
			}
			while(ch!='\0');
			
		} catch (FileNotFoundException  e) {

			e.printStackTrace();
		}
	}

}
