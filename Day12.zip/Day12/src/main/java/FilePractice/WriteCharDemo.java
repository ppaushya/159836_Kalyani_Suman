package FilePractice;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharDemo {

	public static void main(String[] args) throws IOException {
		String str="Greetings!!!";
		
		File file=new File("D:\\Users\\kalsuman\\Desktop\\Module2\\ExampleFile\\writeDemo.txt");
		try (FileWriter writer=new FileWriter(file))//close resource
		{
			/*char[] ch=str.toCharArray();
			for(char c:ch)
			{
				writer.write(c);
			}*/
			
			writer.write(str);
			
		} catch (FileNotFoundException  e) {

			e.printStackTrace();
		}

	}

}
