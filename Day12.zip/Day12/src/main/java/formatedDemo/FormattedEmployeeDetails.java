package formatedDemo;

import java.util.Scanner;
import java.io.*;


public class FormattedEmployeeDetails {

	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) throws FileNotFoundException {

		int empId;
		double salary;
		boolean isPermanent;
		char gender = 0 ;
		String name;
		
		File file=new File("D:\\Users\\kalsuman\\Desktop\\Module2\\ExampleFile\\employee.txt");
		try(FileOutputStream out=new FileOutputStream(file);
				DataOutputStream outputStream=new DataOutputStream(out)){
			
			for(int i=0;i<5;i++)
			{
				System.out.println("Enter emp id: ");
				empId=scanner.nextInt();
				System.out.println("Enter salary: ");
				salary=scanner.nextDouble();
				System.out.println("Enter status of employee: ");
				isPermanent=scanner.nextBoolean();
				System.out.println("Enter gender: ");
				System.out.println("Enter name of employee: ");
				name=scanner.next();
				
				outputStream.writeInt(empId);
				outputStream.writeDouble(salary);
				outputStream.writeBoolean(isPermanent);
				outputStream.writeChar(gender);
				outputStream.writeInt(name.length());
				outputStream.write(name.getBytes());
				
			}
			
		}catch(IOException e){
			
			e.printStackTrace();
		}
		
		try(FileInputStream out=new FileInputStream(file);
				DataInputStream outputStream=new DataInputStream(out)){
			
			for(int i=0;i<5;i++)
			{
				String EmpName;
			}
		}catch(IOException e){
			
			e.printStackTrace();
		}

	}

}
