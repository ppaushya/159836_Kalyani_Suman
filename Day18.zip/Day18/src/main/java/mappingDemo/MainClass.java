package mappingDemo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {

EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		CustomerClass customer=new CustomerClass(101,"Jack");
		Address address=new Address(1,"13 park street",customer);
		
		//entityManager.persist(customer);
		
		entityManager.persist(address);
		
		transaction.commit();

	}

}
