package mappingDemo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {

	@Id
	private int addressId;
	private String addressLine;
	
	//unidirectional mapping
	
	@OneToOne(cascade=CascadeType.ALL,mappedBy="address")
	@JoinColumn(name="cust_fk")
	private CustomerClass customer;
	
	public Address()
	{
		
	}

	public Address(int addressId, String addressLine, CustomerClass customer) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
		this.customer = customer;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public CustomerClass getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerClass customer) {
		this.customer = customer;
	}
	
	
	
	
}
