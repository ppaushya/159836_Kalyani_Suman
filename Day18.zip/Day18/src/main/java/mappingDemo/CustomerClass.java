package mappingDemo;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class CustomerClass {


	@Id
	private int customerId;
	private String name;
	
	@OneToOne(mappedBy="customerclass")
	@JoinColumn(name="add_fk")
	Address address;
	
	public CustomerClass()
	{
		super();
	}
	public CustomerClass(int customerId, String name) {
		super();
		this.customerId = customerId;
		this.name = name;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
