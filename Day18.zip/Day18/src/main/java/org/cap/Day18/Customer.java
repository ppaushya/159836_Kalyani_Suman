package org.cap.Day18;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	@Id
	private CustomerCompositeKey custCompositeKey;
	private String firstName ;
	private String lastName;
	
	public Customer()
	{
		
	}
	
	public Customer(CustomerCompositeKey custCompositeKey, String firstName, String lastName) {
		super();
		this.custCompositeKey = custCompositeKey;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public CustomerCompositeKey getCustCompositeKey() {
		return custCompositeKey;
	}
	public void setCustCompositeKey(CustomerCompositeKey custCompositeKey) {
		this.custCompositeKey = custCompositeKey;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	
	

}
