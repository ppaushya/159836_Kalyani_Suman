package org.cap.Day18;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
	
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		CustomerCompositeKey custCompositeKey=new CustomerCompositeKey(111,"ASK-111");
		Customer customer=new Customer(custCompositeKey,"Jack","Thomson");
		
		entityManager.persist(customer);
		
		transaction.commit();

	}

}
