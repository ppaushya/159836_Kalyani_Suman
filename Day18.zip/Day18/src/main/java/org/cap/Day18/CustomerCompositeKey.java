package org.cap.Day18;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CustomerCompositeKey implements Serializable{

	private int customerId;
	private String userId;
	
	public CustomerCompositeKey()
	{
	
	}
	
	
	public CustomerCompositeKey(int customerId, String userId) {
		super();
		this.customerId = customerId;
		this.userId = userId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
