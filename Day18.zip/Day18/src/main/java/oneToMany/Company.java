package oneToMany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Company {

	@Id
	private int companyId;
	private String companyname;
	
	@OneToMany//(mappedBy="company",targetEntity=Employee.class,cascade=CascadeType.ALL)
	@JoinColumn(name="employee_fk")
	private List<Employee> employees;

	public Company()
	{
		
	}
	public Company(int companyId, String companyname) {
		super();
		this.companyId = companyId;
		this.companyname = companyname;
		
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyname() {
		return companyname;
	}

	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	
}
