package oneToMany;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee implements Serializable{

	@Id
	private int empId;
	private String empName;
	
	@ManyToOne//(cascade=CascadeType.ALL)
	@JoinColumn(name="company_fk")
	private Company company;
	
	public Employee()
	{
		
	}

	public Employee(int empId, String empName, Company company) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.company = company;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	
	
}
