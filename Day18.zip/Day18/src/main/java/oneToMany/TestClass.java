package oneToMany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		Company capg=new Company(121,"Capgemini");
		Company tcs=new Company(131,"TCS");
		
		Employee employee=new Employee(101,"Tom",  capg);
		
		entityManager.persist(employee);
		
		transaction.commit();
	}

}
