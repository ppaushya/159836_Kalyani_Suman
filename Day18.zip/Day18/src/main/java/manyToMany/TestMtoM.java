package manyToMany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestMtoM {

	public static void main(String[] args) {
		
		
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Event e1=new Event(1001,"Java");
		Event e2=new Event(1002,"Oracle");
		List<Event> events=new ArrayList<>();
		events.add(e1);
		events.add(e2);
		
		Delegate d1=new Delegate(121,"Tom",events);
		
		
		entityManager.persist(d1);
		
		
		
		transaction.commit();

	}

}
