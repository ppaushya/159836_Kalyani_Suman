package manyToMany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Event {
	
	@Id
	private int eventId;
	private String eventName;
	
	@ManyToMany
	@JoinTable(name="event_delegate", 
	joinColumns=@JoinColumn(name="event_id"),
	inverseJoinColumns = @JoinColumn(name = "delegate_id")
			)
	
	List<Delegate> delegates=new ArrayList<>();
	
	
	public List<Delegate> getDelegates() {
		return delegates;
	}

	public void setDelegates(List<Delegate> delegates) {
		this.delegates = delegates;
	}

	public Event()
	{
		
	}
	
	public Event(int eventId, String eventName) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	
	
	

}
