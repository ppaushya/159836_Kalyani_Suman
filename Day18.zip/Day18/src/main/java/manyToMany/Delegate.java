package manyToMany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Delegate {

	@Id
	private int delegateId;
	private String delegateName;
	
	@ManyToMany
	@JoinTable(name="event_delegate", joinColumns= {
			@JoinColumn(name="delegates_fk")
			})
	
	List<Event> events=new ArrayList<>();
	
	
	public Delegate()
	{
		
	}
	
	public Delegate(int delegateId, String delegateName, List<Event> events) {
		super();
		this.delegateId = delegateId;
		this.delegateName = delegateName;
		this.events = events;
	}

	public Delegate(int delegateId, String delegateName) {
		super();
		this.delegateId = delegateId;
		this.delegateName = delegateName;
	}
	public int getDelegateId() {
		return delegateId;
	}
	public void setDelegateId(int delegateId) {
		this.delegateId = delegateId;
	}
	public String getDelegateName() {
		return delegateName;
	}
	public void setDelegateName(String delegateName) {
		this.delegateName = delegateName;
	}
	
	
	
	
	
}
