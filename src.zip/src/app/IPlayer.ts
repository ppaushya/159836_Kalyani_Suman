export interface IPlayer{
    playerId: number;
    playerName: string;
    playerCountry: string;
    battingAvg: number;
    description: string;
    runs: number;
    wickets: number;
    imageUrl:string;
    playerRating:number;
}