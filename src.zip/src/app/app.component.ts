import { Component } from '@angular/core';
import { ProductService } from './product/product.service';

@Component(/*meta data*/{
  selector: 'pm-root',//class
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ProductService]
  
})
export class AppComponent {
  title = 'Angular: Getting Started';
}