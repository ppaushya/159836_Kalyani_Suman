import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    
  templateUrl: './registration.component.html'
  //template:`<h1>bjb</h1>`
})
export class RegistrationComponent {
    public pageTitle: string = 'Welcome';
}
