//global
var num=100;
function demo(){
	
	//local
	var count=0;
	console.log(count)
	//block
	{
		
	}
	
}
demo()