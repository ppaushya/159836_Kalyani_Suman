function createCustomer(customerId,name,regFee,address){
	this.customerId=customerId;
	this.name=name;
	this.regFee=regFee;
	this.address=address;
	
	this.setCustomerId=function(customerId){
		this.customerId=customerId
	}
	
	this.getCustomerId=function(){
		return this.customerId
	}
	
	this.printDetails=function(){
		console.log('Customer ID--'+customer.customerId)
		console.log('Customer Name--'+customer.name)
		console.log(customer.regFee)
		console.log(customer.address)
	}
	
}

var customer=new createCustomer(1001,'Tom',2000,'13 baker street');

customer.printDetails()
customer.setCustomerId(2111)
customer.printDetails()