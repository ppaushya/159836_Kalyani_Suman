function Employee(name){
	this.name=name;
}

Employee.prototype.getName=function(){
	return this.name;
}

function Department(name,manager){
	this.name=name;
	this.manager=manager;
}

Department.prototype.getDepName=function(){
	return this.name;
}

var emp=new Employee("Tom");

var dep=new Department("Sales","Jerry");

console.log("Emp name: "+emp.getName());
console.log("Dep name: "+dep.getDepName());

/*1.method 
dep._proto_=emp;//dep inherit from emp
//console.log("dep.getName()-- "+dep.getName());

console.log("dep._proto_.getName()-- "+dep._proto_.getName());*/

//method 2--by using prototype Object
var dep1=Object.create(emp);
console.log("dep1.getName()-- "+dep1.getName());

//method3-- by using Prototype 
Department.prototype=new Employee("Jack");
//????