var emp={
		empId:1001,
		firstName:'Tom',
		lastName:'Jerry',
		salary:23000,
		address:{
			city:'chennai',
			state:'TN'
		}
	}

var myFun=function(){
	
	console.log(emp)
	console.log(emp.empId)//console.log(emp["empId"]) is same
	console.log(emp.address)//access object address
	console.log(emp["address"]["city"])
	
	//enhanced for loop
	for(key in emp){
		console.log(key+'--'+emp[key])
		
	}
	
	
}
myFun()