function setCustomer(){
	var customerId;
	var name;
	var regFee;
	var address;
	
	this.setCustomerId=function(customerId){
		this.customerId=customerId
	}
	
	this.getCustomerId=function(){
		return this.customerId
	}
	
	this.printDetails=function(){
		console.log('Customer ID--'+customer.customerId)
		console.log('Customer Name--'+customer.name)
		console.log(customer.regFee)
		console.log(customer.address)
	}
	
}
var customer={}
customer.setCustomerId(2111)
customer.getCustomerId()