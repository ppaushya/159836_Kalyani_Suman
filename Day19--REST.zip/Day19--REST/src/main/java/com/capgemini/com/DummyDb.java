package com.capgemini.com;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.model.Product;

public class DummyDb {
	
	private List<Product> products=getAllProducts();

	private List<Product> getAllProducts() {

		List<Product> products=new ArrayList<>();
		products.add(e);
		products.add(e)
		
		return null;
	}
	
	

}
