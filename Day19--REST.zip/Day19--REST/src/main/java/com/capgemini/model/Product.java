package com.capgemini.model;

public class Product {
	
	private int productId;
	private String productName;
	

}
