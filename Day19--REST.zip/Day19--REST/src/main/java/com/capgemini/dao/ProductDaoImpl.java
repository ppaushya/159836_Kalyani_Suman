package com.capgemini.dao;

public class ProductDaoImpl implements IProductDao{

}
