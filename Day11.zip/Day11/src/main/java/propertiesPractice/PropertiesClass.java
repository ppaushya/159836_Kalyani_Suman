package propertiesPractice;

import java.util.List;
import java.util.Properties;
import java.util.Set;

public class PropertiesClass {
	public static void main(String[] args)
	{
		Properties properties=new Properties();
		properties.put("firstName", "Jack");
				properties.put("lastName", "Thomsan");
				properties.put("Salary", 12000);
				
				Set<Object> keys=properties.keySet();
				for(Object key:keys)
				{
					System.out.println(key+"-->"+properties.get(key));
				}
	}

}
