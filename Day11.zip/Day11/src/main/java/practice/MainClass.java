package practice;

import org.apache.log4j.Logger;

public class MainClass {

	final static Logger logger=Logger.getLogger(MainClass.class);
	public static void main(String[] args) {
		
		MainClass obj=new MainClass();
		obj.runMe("Hello World");
		
	/*ITransactionDao dao=new TransactionDaoImpl();
	dao.performTransaction();*/
	}
	
	public void runMe(String parameter)
	{
		if(logger.isDebugEnabled())
		{
			logger.debug("This is debug: "+parameter);
		}
		
		if(logger.isInfoEnabled())
		{
			logger.info("This is info: "+parameter);
		}
		try {
			ITransactionDao dao=new TransactionDaoImpl();
			dao.performTransaction();
			
		}catch(Exception e)
		{
			logger.error("Sorry! Something went wrong",e);
			e.printStackTrace();
		}
		logger.warn("This is warn: "+parameter);
		logger.error("This is error: "+parameter);
		logger.fatal("This is fatal: "+parameter);
	}
}
