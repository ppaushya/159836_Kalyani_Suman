package practice;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Savepoint;
import java.time.LocalDate;
import java.util.Properties;
import java.sql.SQLException;


public class TransactionDaoImpl  implements ITransactionDao{


	@Override
	public void performTransaction() {
		Connection conn=null;
		Savepoint s1=null,s2=null,s3=null;
		try{
			conn=getDbConnection();
			//AutoCommit disabled
			conn.setAutoCommit(false);
			Employee employee=new Employee(189, "jas", "annie", 12000	, LocalDate.of(2012, 3, 12));
			
			String sql="insert into employee values(?,?,?,?,?)";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, employee.getEmpId());
			pst.setString(2, employee.getFirstName());
			pst.setString(3, employee.getLastName());
			pst.setDouble(4, employee.getSalary());
			pst.setDate(5, java.sql.Date.valueOf(employee.getEmpdoj()));
			int count=pst.executeUpdate();
			if(count>=1)
				System.out.println("Employee inserted!");
			 s1=conn.setSavepoint("s1");
			
			
			
			double bonus=employee.getSalary()*3/10;
			String sql1="insert into bonusInfo values(?,?)";
			pst=conn.prepareStatement(sql1);
			pst.setInt(1, employee.getEmpId());
			pst.setDouble(2, bonus);
			int count1=pst.executeUpdate();
			
			if(count1>=1)
				System.out.println("Bonus inserted!");
			 s2=conn.setSavepoint("s2");
			
			String sql2="insert into transaction(transdate,status) values(?,?)"	;
			pst=conn.prepareStatement(sql2);
			pst.setDate(1, Date.valueOf(LocalDate.now()));
			pst.setString(2, "completed");
			int count2=pst.executeUpdate();
			 s3=conn.setSavepoint("s3");
			if(count2>=1)
				System.out.println("Transaction inserted!");
			
			if(count>=1 &&count1>=1 && count2>=1 )
				//Commit your Transaction
				conn.commit();
			
			
		}
		/*catch (ArithmeticException e) {
			// TODO: handle exception
		}*/
		catch (ArithmeticException | SQLException e) {
			
			try {
				//Rollback Trans
				conn.rollback(s1);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	private InputStream getPath()
	{
		return this.getClass().getResourceAsStream("jdbc.properties");
	}

	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Properties properties=new Properties();
			properties.load(getPath());
			
			//Class.forName("com.mysql.jdbc.Driver");
			Class.forName(properties.getProperty("driverClass"));
			connection=DriverManager.getConnection
					(properties.getProperty("url"), properties.getProperty("username"), properties.getProperty("pswd"));
			return connection;
		}catch (ClassNotFoundException |SQLException e) {
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}

	
	
	

}
