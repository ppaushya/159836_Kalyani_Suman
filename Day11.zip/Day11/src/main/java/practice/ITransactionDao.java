package practice;

public interface ITransactionDao {

	public void performTransaction();
}
