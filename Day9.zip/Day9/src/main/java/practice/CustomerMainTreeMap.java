package practice;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class CustomerMainTreeMap {

	public static void main(String[] args) {
		
Map<Customer,Address> map=new TreeMap<>();
		
		map.put(new Customer(111,"tom"), new Address("chennai","TN"));
		map.put(new Customer(456,"jerry"), new Address("mfp","BH"));
		map.put(new Customer(12,"jack"), new Address("ptn","BH"));
		map.put(new Customer(496,"kamal"), new Address("chennai","TN"));
		map.put(new Customer(1892,"hasan"), new Address("chennai","TN"));
		map.put(new Customer(111,"tom"), new Address("ptn","BH"));
		//override hashcode() and equals() to avoid duplicate key i.e customer
//		System.out.println(map);
		
		Set<Customer> set=map.keySet();
		Iterator<Customer> iterator=set.iterator();
		while(iterator.hasNext())
		{
			Customer key=iterator.next();
			System.out.println(key+"-->"+map.get(key));
	}

	}

}
