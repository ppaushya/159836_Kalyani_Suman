package practice;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class ArrayListMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> employee=new ArrayList<>();
		employee.add(new Employee(191,"tom","jerry",25,25000));
		employee.add(new Employee(121,"jack","jerry",52,5233));
		employee.add(new Employee(113,"tom","jack",15,25000));
		employee.add(new Employee(151,"jerry","jack",65,55422));
		
		employee.add(new Employee(151,"jerry","jack",65,55422));
		
		Iterator<Employee> iterator=employee.iterator();//headpointer
		
		while(iterator.hasNext())
		{
			Employee emp=iterator.next();
			System.out.println(emp+" ");
		}
		System.out.println();

		Collections.sort(employee); //take comparable
		iterator=employee.iterator();
		while(iterator.hasNext())
		{
			Employee emp=iterator.next();
			System.out.println(emp+" ");
		}
		System.out.println();
		
		Collections.sort(employee, new SortByName());
		iterator=employee.iterator();
		while(iterator.hasNext())
		{
			Employee emp=iterator.next();
			System.out.println(emp+" ");
		}
		System.out.println();
		
		Collections.sort(employee,new Comparator<Employee>() {

			@Override
			public int compare(Employee o1, Employee o2) {
				// TODO Auto-generated method stub
				if(o1.getSalary()>o2.getSalary())
					return 1;
				else if(o1.getSalary()<o2.getSalary())
					return -1;
				else
					return 0;
			}
			
		});
		
		
	}

}
