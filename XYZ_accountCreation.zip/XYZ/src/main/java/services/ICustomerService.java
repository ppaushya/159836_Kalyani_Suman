package services;

import java.util.List;
import java.util.Set;

import model.Account;
import model.Customer;

public interface ICustomerService {

	public void createCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public Customer isFound(int customerId);
	//public Set<Customer> getAccountDetails();
	public void AddAccount(Customer customer,Account account);
}
