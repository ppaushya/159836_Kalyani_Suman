package dao;

import java.util.List;
import java.util.Set;

import model.Account;
import model.Customer;

public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);
	public Customer isFound(int customerId);
	public void AddAccount(Customer customer,Account account);
}
