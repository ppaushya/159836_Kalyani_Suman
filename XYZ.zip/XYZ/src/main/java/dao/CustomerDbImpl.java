package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import model.Account;
import model.Address;
import model.Customer;
import model.Transaction;

public class CustomerDbImpl implements ICustomerDao{

	private Connection getDbConnection() {
		Connection conn=null;
		try{
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
	
			Class.forName("com.mysql.jdbc.Driver");
			return conn;
		}catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return null;
		
		
	}
	@Override
	public List<Customer> getAllCustomers() {

		List<Customer> customers=new ArrayList<>();
		
		String sql="select * from customer";
		try(Connection conn=getDbConnection()) {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet resultSet= pst.executeQuery();
			while(resultSet.next()) {
				Customer customer=new Customer();
				customer.setCustomerId(resultSet.getInt(1));
				customer.setFirstName(resultSet.getString(2));
				customer.setLastName(resultSet.getString(3));
				customer.setDateOfBirth(resultSet.getDate(4).toLocalDate());
				customer.setEmailId(resultSet.getString(5));
				customer.setMobile(resultSet.getString(6));
				//customer.set
				
				customers.add(customer);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return customers;		
		
	}

	public void createAddress(Address address)
	{
		/*statement.setString( addressLine1);
		statement.setString( addressLine2);
		statement.setString (city);
		statement.setString(state);
		statement.setString (pincode);*/
	}
	public void dummyCustomerOb()
	{
		try {
			Connection conn=getDbConnection();
			String sql="create table customer(custId int primary key,fName varchar(25),lName varchar(25),dob date,email varchar(30),mobile varchar(10))";
			Statement stmt=conn.createStatement();
			boolean flag=stmt.execute(sql);
			if(!flag)
			{
				System.out.println("Table created successfully!");
			}
			
			sql="Insert into customer values(123,'Jack','Thomson', '1991-01-23','jack@gmail.com','8890912345')";
			stmt=conn.createStatement();
			int count=stmt.executeUpdate(sql);
			if(count>0)
			{
				System.out.println("Row Inserted");
			}
			sql="Insert into customer values(1090,'Tom','Jerry', '1996-01-23','tom@gmail.com','9876543211')";
			stmt=conn.createStatement();
			count=stmt.executeUpdate(sql);
			if(count>0)
			{
				System.out.println("Row Inserted");
			}
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		
	}
	@Override
	public void createCustomer(Customer customer) {
		Connection conn=getDbConnection();
		
		try {
			String sql="create table customer(custId int primary key,fName varchar(25),lName varchar(25),dob date,email varchar(30),mobile varchar(10))";
			Statement stmt=conn.createStatement();
			boolean flag=stmt.execute(sql);
			if(!flag)
			{
				System.out.println("Table created successfully!");
			}
			
			 sql="Insert into customer values(?,?,?,?,?)";
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setInt(1,customer.getCustomerId());
			statement.setString(2,customer.getFirstName());
			statement.setString(3, customer.getLastName());
			statement.setDate(4, java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(5,customer.getEmailId());
			statement.setString(6,customer.getMobile());
//			createAddress(Address address);
			
			int count=statement.executeUpdate();
			if(count!=0)
			{
				System.out.println("Row Inserted!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Customer isCustomerFound(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account isAccountFound(Customer customer, int accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void AddAccount(Customer customer, Account account) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Transaction> getAllTransaction() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getCurrentBalance(Account account, int accountNumber) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	

}
