package com.capgemini.controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.model.Register;

public class RegisterController {

	private Register register;
	
	@RequestMapping("/registerForm")
	public String registerCustomer(ModelMap map, @ModelAttribute("register") Register register)
	{
		map.addAttribute("register", new Register());
		return "success";
	}
	
}
