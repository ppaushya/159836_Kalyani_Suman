package com.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.model.Register;

@Controller
public class LoginController {
	
	
	@PostMapping("/validLogin")
	public String validLogin(ModelMap map,@RequestParam("userName")String userName , @RequestParam("userPwd")String userPwd) {
		
		if(userName.equals("tom") && userPwd.equals("tom123"))
		{
			map.addAttribute("userName",userName);
			map.addAttribute("register",new Register());
			return "register";
		
		}
		return "redirect:/";
		
	}
	
	
	}
