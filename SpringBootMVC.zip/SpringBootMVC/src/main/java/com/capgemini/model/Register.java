package com.capgemini.model;

import java.util.Date;

public class Register {

	private int customerId;
	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String gender;
	private String qualification;
	private Date dateOfBirth;
	private String emailId;
	private String mobile;
	private String customerPwd;
	private String confirmPassword;
	
	public Register() {}

	public Register(int customerId, String firstName, String lastName, String address, String city, String gender,
			String qualification, Date dateOfBirth, String emailId, String mobile, String customerPwd,String confirmPassword) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.gender = gender;
		this.qualification = qualification;
		this.dateOfBirth = dateOfBirth;
		this.emailId = emailId;
		this.mobile = mobile;
		this.customerPwd = customerPwd;
		this.confirmPassword=confirmPassword;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getCustomerPwd() {
		return customerPwd;
	}

	public void setCustomerPwd(String customerPwd) {
		this.customerPwd = customerPwd;
	}
	
	

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	@Override
	public String toString() {
		return "Register [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + ", city=" + city + ", gender=" + gender + ", qualification=" + qualification
				+ ", dateOfBirth=" + dateOfBirth + ", emailId=" + emailId + ", mobile=" + mobile + ", customerPwd="
				+ customerPwd + ", confirmPassword=" + confirmPassword + "]";
	}
	
	
}
