package loggerDemo;

import org.apache.log4j.Logger;

public class HelloExample {

	final static Logger logger=Logger.getLogger(HelloExample.class);
	public static void main(String[] args) {
		
		HelloExample obj=new HelloExample();
		obj.runMe("Hello World");

	}
	public void runMe(String parameter)
	{
		if(logger.isDebugEnabled())
		{
			logger.debug("This is debug: "+parameter);
		}
		
		if(logger.isInfoEnabled())
		{
			logger.info("This is info: "+parameter);
		}
		try {
			int num1=45,num2=0;
			int ans=num1/num2;
			
		}catch(ArithmeticException e)
		{
			logger.error("Sorry! Something went wrong",e);
			e.printStackTrace();
		}
		logger.warn("This is warn: "+parameter);
		logger.error("This is error: "+parameter);
		logger.fatal("This is fatal: "+parameter);
	}

}
