package com.capgemini;

import javax.xml.ws.Endpoint;

public class CalculatorPublisher {

	public static void main(String[] args) {


		Endpoint.publish("http://localhost:7709/ws/ICalculator", new CalculatorImpl());

	}

}
//http://localhost:7709/ws/ICalculator?wsdl