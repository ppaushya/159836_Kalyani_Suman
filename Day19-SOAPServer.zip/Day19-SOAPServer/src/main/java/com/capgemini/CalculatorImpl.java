package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.ICalculator")
public class CalculatorImpl implements ICalculator{

	@Override
	public int addNumber(int num1, int num2) {
		
		return num1+num2;
	}
	

}
