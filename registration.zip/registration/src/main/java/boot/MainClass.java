package boot;

import java.util.Scanner;

import model.Registration;
import service.IRegistrationService;
import service.RegistrationServiceImpl;
import view.UserInteraction;

public class MainClass {
	
	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {

		IRegistrationService registrationService=new RegistrationServiceImpl();
		//registrationService.createTable();
		Registration registration=new Registration();
		String  choice;
		do {
			int option;
			System.out.println("1. Customer Registration");
			System.out.println("2. Exit");
			option =scanner.nextInt();
			switch(option) {
			case 1:
				registration = UserInteraction.promptRegistration();
				Registration registration1 = UserInteraction.createRegistration(registration);
				if(registration1!=null) {
					UserInteraction.printAcknowledgement(registration1);
				}else {
					System.out.println("");
				}
			case 2:
				
				break;
			}
			System.out.println("Enter [y/n]: ");
			choice= scanner.next();
		}while(choice=="y" || choice=="Y");
	}

}
