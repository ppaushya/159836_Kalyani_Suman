package model;

public class Registration {
	private int registrationId;
	private String customerName;
	private String mobileNo;
	private double registrationFee;
	private int age;
	private double regFeePaid;
	
	
	
	public Registration() {
		super();
	}

	public Registration(int registrationId, String customerName, String mobileNo, double registrationFee, int age,
			double regFeePaid) {
		super();
		this.registrationId = registrationId;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.registrationFee = registrationFee;
		this.age = age;
		this.regFeePaid = regFeePaid;
	}
	
	@Override
	public String toString() {
		return "Registration [registrationId=" + registrationId + ", customerName=" + customerName + ", mobileNo="
				+ mobileNo + ", registrationFee=" + registrationFee + ", age=" + age + ", regFeePaid=" + regFeePaid
				+ "]";
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public double getRegistrationFee() {
		return registrationFee;
	}
	public void setRegistrationFee(double registrationFee) {
		this.registrationFee = registrationFee;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getRegFeePaid() {
		return regFeePaid;
	}
	public void setRegFeePaid(double regFeePaid) {
		this.regFeePaid = regFeePaid;
	}
	
	

}
