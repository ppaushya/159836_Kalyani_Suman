package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.log4j.Logger;


import model.Registration;

public class RegistrationDaoImpl implements IRegistrationDao{

	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	
	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			logger.info("Datebase connection established.");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e);
			e.printStackTrace();
		}
		return null;
	}
	
	
	@Override
	public Registration createRegistration(Registration registration) {
		String query = "INSERT INTO registration (id,name,mobile,registrationFees,age,RegFeesPaid) VALUES(?,?,?,?,?,?)";

		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1,registration.getRegistrationId());
			statement.setString(2, registration.getCustomerName());
			statement.setString(3,registration.getMobileNo());
			statement.setDouble(4, registration.getRegistrationFee());
			statement.setInt(5, registration.getAge());
			statement.setDouble(6, registration.getRegFeePaid());
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Registration successful.");
				logger.info("Registration successful. "+registration.toString());
				String sql="select * from registration";
				statement=connection.prepareStatement(sql);
				ResultSet resultSet= statement.executeQuery();
				
				Registration  registration1=new Registration();
				while(resultSet.next()) {
					
					registration1.setRegistrationId(resultSet.getInt(1));
					registration1.setCustomerName(resultSet.getString(2));
					registration1.setMobileNo(resultSet.getString(3));
					registration1.setRegistrationFee(resultSet.getDouble(4));
					registration1.setAge(resultSet.getInt(5));
					registration1.setRegFeePaid(resultSet.getDouble(6));
				
				}
				return registration1;
			}else {
				System.out.println("Error occured.");
				
			} 
		} catch (Exception  e) {//SQLException
			logger.error("Error occured."+e);
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void createTable() {
		
		try(Connection connection = getConnection()) {
			String sql="CREATE TABLE registration(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(25),mobile VARCHAR(12)," + 
					"registrationFees NUMERIC(8,2), age INT,RegFeesPaid NUMERIC(8,2))";
			Statement statement=connection.createStatement();
			boolean flag=statement.execute(sql);
			if(!flag){
				System.out.println("Table created successfully!");
			}
	   } catch(SQLException e)//checked exception
			{
				e.printStackTrace();
			}
			
		}
	}

