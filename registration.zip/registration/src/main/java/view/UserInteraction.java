package view;

import java.util.Scanner;

import org.apache.log4j.Logger;

import dao.RegistrationDaoImpl;
import exception.InvalidAgeException;
import model.Registration;
import service.IRegistrationService;
import service.RegistrationServiceImpl;

public class UserInteraction {

	static Scanner scanner = new Scanner(System.in);
	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	
	
	public static Registration promptRegistration() {
		Registration registration = new Registration();
		
		System.out.println("Enter customer name: ");
		String customerName=scanner.next();
		while(!customerName.matches("[a-zA-Z ]+")) {
			System.out.println("Invalid! Enter name again: ");
			customerName = scanner.next();
		}
		registration.setCustomerName(customerName);
		
		System.out.println("Enter mobile number: ");
		String mobile= scanner.next();
		while(!mobile.matches("(7|8|9)\\d{9}")) {
			System.out.println("Invalid! Enter mobile number again: ");
			mobile = scanner.next();
		}
		registration.setMobileNo(mobile);
		
		System.out.println("Enter registration fee: ");
		double registrationFee=scanner.nextDouble();
		while(registrationFee<=0) {
			System.out.println("Invalid! Enter Registration Fees again: ");
			registrationFee = scanner.nextDouble();
		}
		registration.setRegistrationFee(registrationFee);
		
		System.out.println("Enter your age: ");
		int age=scanner.nextInt();
		while(age<=0) {
			System.out.println("Invalid! Enter Age again: ");
			age = scanner.nextInt();
		}
		registration.setAge(age);
		
		logger.debug("Registration prompted.");
		return registration;
	}
	
	public static void printAcknowledgement(Registration registration) {
	
		System.out.println("|           Acknowledgement                |");
		System.out.println("Registration Id: "+registration.getRegistrationId());
		System.out.println("Congratulation!!! "+registration.getCustomerName());
		System.out.println("\nYou are registered.\n");
		System.out.println("Fees paid : "+registration.getRegFeePaid());
		System.out.println("\n---------------------------------\n\n");
		
	}
	
	public static Registration createRegistration(Registration registration){
		IRegistrationService registrationService = new RegistrationServiceImpl();
		try {
			Registration registration2 = registrationService.createRegistration(registration);
			return registration2;
		} catch (InvalidAgeException e) {
			System.out.println("Invalid Age.");
			e.printStackTrace();
		}
		return null;
	}
}
