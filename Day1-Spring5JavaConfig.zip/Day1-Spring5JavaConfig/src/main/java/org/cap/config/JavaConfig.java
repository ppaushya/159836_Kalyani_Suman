package org.cap.config;

import org.cap.model.Address;
import org.cap.model.Employee;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {

	@Bean
	public Employee getEmployeeBean() {
		//return new Employee(1001,"Tom",20000);
		
		Employee employee=new Employee();
		employee.setEmployeeName("thomson");
		employee.setSalary(40000);
		return employee;
	}
	
	@Bean(name="address1")
	public Address getAddressBean() {
		return new Address("North Avenue","Chennai");
	}
	
	@Bean(name="address2")
	public Address getAddressBean1() {
		return new Address("South Avenue","Chennai");
	}
}
