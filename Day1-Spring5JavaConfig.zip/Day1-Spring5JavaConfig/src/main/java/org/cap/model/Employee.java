package org.cap.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Employee {
	
	private int employeeId;
	private String employeeName;
	private double salary;
	
	@Autowired
	@Qualifier("address2")
	private Address address;
	
	public Employee()
	{
		System.out.println("no arg constructor called");
	}
	public Employee(int employeeId, String employeeName, double salary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		System.out.println(" constructor with 3 arguments called");
	}

	
	public Employee(int employeeId, String employeeName, double salary, Address address) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.address = address;
		System.out.println(" constructor with 4 arguments called");
	}
	public Address getAddress() {
		return address;
	}
//	@Autowired
//	@Qualifier("address2")
	public void setAddress(Address address) {
		this.address = address;
		System.out.println("setter method");
	}
	public int getEmployeeId() {
		return employeeId;
	}
	@Required
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
		System.out.println("setEmployeeId called");
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;

	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
				+ ", address=" + address + "]";
	}
	
	@PostConstruct
	public void init_method()
	{
		System.out.println("employee bean created");
	}
	
	@PreDestroy
	public void destroy_method()
	{
		System.out.println("employee bean destroyed");
	}

}
