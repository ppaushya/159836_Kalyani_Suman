package customTagsDemo;

import java.io.IOException;
import java.io.StringWriter;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class userGreeting extends SimpleTagSupport{
	
	private String user;
	private String color;
	
	
	
	public String getUser() {
		return user;
	}



	public void setUser(String user) {
		this.user = user;
	}



	public String getColor() {
		return color;
	}



	public void setColor(String color) {
		this.color = color;
	}



	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out= getJspContext().getOut();
		
		LocalTime time=LocalTime.now();
		int hrs=time.getHour();
	
		if(hrs>=1 && hrs<=10)
		{
		if(user==null)
		out.println("<h3>Good Morning! <span style='color:"+getColor()+"'>"+"Capgemini</h3>");
		else
			out.println("<h3>Good Morning! <span style='color:"+getColor()+"'>"+getUser()+"</h3>");
		}
		else if(hrs>=10 && hrs<=14)
		{
			if(user==null)
				out.println("<h3>Good Afternoon! <span style='color:"+getColor()+"'>"+"Capgemini</h3>");
				else
					out.println("<h3>Good Afternoon! <span style='color:"+getColor()+"'>"+getUser()+"</h3>");
		}
		else 
		{
			if(user==null)
				out.println("<h3>Good Evening! <span style='color:"+getColor()+"'>"+"Capgemini</h3>");
				else
					out.println("<h3>Good Evening! <span style='color:"+getColor()+"'>"+getUser()+"</h3>");
		}
		
		
	}

}
