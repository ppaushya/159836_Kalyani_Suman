package practice;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyFirstTest {

	@Test
	public void testAddNumberMethod() {//always void
		//fail("Not yet implemented");
		Calculate calculate=new Calculate();
		assertEquals(15,calculate.addNumber(5,10));
		assertEquals(-5,calculate.subtractNumber(5,10));
		assertEquals(true,calculate.fun(5));
		
	}

}
