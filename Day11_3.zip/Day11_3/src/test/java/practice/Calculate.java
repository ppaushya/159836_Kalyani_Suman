package practice;

public class Calculate {

	public int addNumber(int i, int j) {
		return i+j;
	}
	int subtractNumber(int i,int j)
	{
		return i-j;
	}
	boolean fun(int i)
	{
		if(i>0)
			return false;
		else
			return true;
	}
		

	
}
