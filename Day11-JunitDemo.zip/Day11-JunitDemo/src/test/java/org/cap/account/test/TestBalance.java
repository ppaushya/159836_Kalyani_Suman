package org.cap.account.test;

import static org.junit.Assert.*;

import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Account;
import org.cap.account.model.Address;
import org.cap.account.model.Customer;
import org.cap.account.service.AccountServiceImpl;
import org.cap.account.service.IAccountService;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestBalance {

	@Test(expected=InvalidAmountException.class)
	public void when_balance_lessthan_1000() throws  InvalidAmountException {
		//Account account=new Account(121, "Saving", 500);
		Customer customer=new Customer();
		customer.setCustomerId(123);
		customer.setCustomerName("gfhjk");
		customer.setAddress(new Address());
		IAccountService accountService=new AccountServiceImpl();
		accountService.createAccount(customer, 1000);
	}
	
	/*@Before
	public void before()
	{
		System.out.println("before ");
	}
	
	@After
	public void after()
	{
		System.out.println("after ");
	}
	
	@After
	
	@BeforeClass
	public void beforeClass()
	{
		System.out.println("before CLASS");
	}
	
	@AfterClass
	public void afterClass()
	{
		System.out.println("AFTER CLASS");
	}*/
}
