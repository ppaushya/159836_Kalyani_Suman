package org.cap.account.service;

import org.cap.account.exception.InvalidAmountException;
import org.cap.account.model.Account;
import org.cap.account.model.Customer;

public interface IAccountService {

	public Account createAccount(Customer customer,double amount) 
			throws InvalidAmountException;
	
	public Account deposit(Account account,double amount);
	public Account withdraw(Account account,double amount);
}
