package org.cap.account.model;

public class Customer {
	
	private int customerId;
	private String customerName;
	private Address address;
	private Account account;
	
	public Customer() {
		
	}
	
	
	public Customer(int customerId, String customerName, Address address, Account account) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.address = address;
		this.account = account;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", address=" + address
				+ ", account=" + account + "]";
	}
	
	
	

}
