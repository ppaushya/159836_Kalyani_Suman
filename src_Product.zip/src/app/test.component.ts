import { Component } from '@angular/core';

@Component(/*meta data*/{
  selector: 'test-root',//class
//templateUrl: './test.component.html'
 template: `
 <div><h1>{{pageTitle}}
 </h1>

 <prod-root></prod-root>
 </div>`
 ,
  // <sports-root></sports-root>
  styleUrls: ['./app.component.css']
 //template:"<h1>{{pageTitle}}</h1>"
})
export class TestComponent {
  //title = 'hey its me';
  pageTitle:string='Product Details';

}