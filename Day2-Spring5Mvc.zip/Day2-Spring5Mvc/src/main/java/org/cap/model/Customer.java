package org.cap.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Customer {
	
	@Id
	@GeneratedValue
	private int customerId;
	@Column(nullable=false)
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	private String emailId;
	private String mobile;
	@Column(nullable=false)
	private String customerPwd;
	

}
