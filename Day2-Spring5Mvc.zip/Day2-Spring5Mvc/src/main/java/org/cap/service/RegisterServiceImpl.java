package org.cap.service;

import java.util.List;

import org.cap.dao.IRegisterDao;
import org.cap.model.Register;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("registerService")
public class RegisterServiceImpl implements IRegisterService{
	
	@Autowired
	private IRegisterDao registerDao;

	@Override
	public void insertRegistration(Register register) {
		registerDao.insertRegistration(register);
		
	}

	@Override
	public List<Register> getAllRegistration() {
		
		return registerDao.getAllRegistration();
	}

	@Override
	public void deleteRegistration(int registrationId) {
		registerDao.deleteRegistration(registrationId);
	}

	@Override
	public Register findRegistration(int registrationId) {
		return registerDao.findRegistration(registrationId);
	}

	@Override
	public void updateRegistration(Register register) {
		registerDao.updateRegistration(register);
		
	}

}
