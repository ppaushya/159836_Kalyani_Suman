package org.cap.service;

import org.cap.model.LoginPojo;

public interface ILoginService {

	public boolean isValidLogin(LoginPojo loginPojo);
}
