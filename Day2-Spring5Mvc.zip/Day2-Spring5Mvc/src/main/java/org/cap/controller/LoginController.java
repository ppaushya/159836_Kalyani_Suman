package org.cap.controller;

import java.util.List;

import org.cap.model.LoginPojo;
import org.cap.model.Register;
import org.cap.service.ILoginService;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@Autowired
	private ILoginService loginService;
	
	@Autowired
	private IRegisterService registerService;
	
	@RequestMapping("/")
	public ModelAndView getIndexPage() {
		
		return new ModelAndView("index", "login", new LoginPojo());
		
	}
	
	@RequestMapping("/validateLogin")
	public String validateLogin(ModelMap map,
			@ModelAttribute("login") LoginPojo loginPojo) {
		List<Register> registers= registerService.getAllRegistration();
		
		if(loginService.isValidLogin(loginPojo)) {
			map.addAttribute("butLabel","update");
			map.addAttribute("register", new Register());
			map.addAttribute("registers", registers);
			
			return "register";
		}
		
		return "redirect:/";
		
	}		
	

	
	
	
	
	
	
	
	
	
}
