package view;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;
import service.CustomerServiceImpl;
import service.ICustomerService;

public class UserInteraction {

	Scanner scanner=new Scanner(System.in);
	public Customer getCustomerDetails() {

		Customer customer=new Customer();
		System.out.print("Enter customer First name: ");
		String firstName=scanner.next();
		while(!firstName.matches("[a-zA-Z ]+")) {
			System.out.print("Invalid!\n Enter First name again: ");
			firstName = scanner.next();
		}
		customer.setFirstName(firstName);
		
		System.out.print("Enter customer Last name: ");
		String lastName=scanner.next();
		while(!lastName.matches("[a-zA-Z ]+")) {
			System.out.print("Invalid!\n Enter Last name again: ");
			lastName = scanner.next();
		}
		customer.setLastName(lastName);
		
		LocalDate dateOfBirth;
		System.out.println("Enter date of birth:");
		System.out.print("Enter year:");
		int year=scanner.nextInt();
		System.out.print("Enter Month:");
		int month=scanner.nextInt();
		System.out.print("Enter dayOfMonth:");
		int dayOfMonth=scanner.nextInt();
		dateOfBirth=LocalDate.of(year, month, dayOfMonth);
		customer.setDateOfBirth(dateOfBirth);
		
		String emailId;
		System.out.print("Enter Email Id: ");
		emailId=scanner.next();
		while(!emailId.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"  
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")) {
			System.out.print("Invalid!\n Enter Email Id again: ");
			emailId = scanner.next();
		}
		customer.setEmailId(emailId);
		
		String mobileNo;
		System.out.print("Enter Mobile Number: ");
		mobileNo=scanner.next();
		while(!mobileNo.matches("\\d{10}")) {
			System.out.print("Invalid!\n Enter Moble Number again: ");
			mobileNo = scanner.next();
		}
		customer.setMobileNo(mobileNo);
		
		return customer;
	}

	public Address getAddressDetails(Customer customer) {

		Address address=new Address();
		
		System.out.print("Enter Address Line1: ");
		String addressLine1=scanner.next();
		address.setAddressLine1(addressLine1);
		
		System.out.print("Enter Address Line2: ");
		String addressLine2=scanner.next();
		address.setAddressLine2(addressLine2);
		
		System.out.print("Enter City: ");
		String city=scanner.next();
		address.setCity(city);
		
		System.out.print("Enter State: ");
		String state=scanner.next();
		address.setState(state);
		
		System.out.print("Enter pincode: ");
		String pincode=scanner.next();
		address.setPincode(pincode);
		
		address.setCustomerId(customer.getCustomerId());
		
		return address;
	}

	public Customer createCustomer(Customer customer) {

		ICustomerService customerService=new CustomerServiceImpl();
		Customer customer1=customerService.createCustomer(customer);
		
		return customer1;
	}

	public Address createAddress(Customer customer, Address address) {
		ICustomerService customerService=new CustomerServiceImpl();
		Address address1=customerService.createAddress(customer,address);
		return address1;
	}

	public void printDetails(Set<Customer> customers, Set<Address> addresses) {

		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()+" "+customer.getFirstName()+" "+
					customer.getLastName()+" "+
		customer.getDateOfBirth()+" "+customer.getEmailId()+" "+
					customer.getMobileNo());
			for( Address address:addresses)
			{
				if(customer.getCustomerId()==address.getCustomerId())
				{
					System.out.println(address.getAddressLine1()+" "+address.getAddressLine2()+ " "+
							address.getCity()+" "+address.getState()+ " "
							+address.getPincode()+" "+address.getAddressId());
				}
			}
			
		}
	}

	public Account createAccount() {

		ICustomerService customerService=new CustomerServiceImpl();
		
		Set<Customer> customers= customerService.getAllCustomer();
		Set<Address> addresses=customerService.getAllAddress();
		printDetails(customers,addresses);
		int customerId;
		System.out.println("Choose customer ID to open a account: ");
		customerId=scanner.nextInt();
		//if(customerService.findCustomer(customerId))
			
		Account account=getAccountDetails(customerId);
		
		Account account1=customerService.createAccount(account);
		
		return account1;
	}

	private Account getAccountDetails(int customerId) {
		Account account =new Account();
		System.out.print("Enter Account Type- Saving,Current,RD,FD: ");
		String accountType=scanner.next();
		account.setAccountType(accountType);
		
		System.out.println("Enter Opening Date ");
		LocalDate openingDate;
		System.out.print("Enter year:");
		int year=scanner.nextInt();
		System.out.print("Enter Month:");
		int month=scanner.nextInt();
		System.out.print("Enter dayOfMonth:");
		int dayOfMonth=scanner.nextInt();
		openingDate=LocalDate.of(year, month, dayOfMonth);
		account.setOpeningDate(openingDate);
		
		System.out.print("Enter Opening Balance: ");
		double openingBalance=scanner.nextDouble();
		account.setOpeningBalance(openingBalance);
		
		System.out.print("Enter Description: ");
		String description=scanner.next();
		account.setDescription(description);
		
		account.setCustomerId(customerId);
		return account;
	}

	public void printAccountDetails(int customerId) {
		Set<Account> accounts=new HashSet<>();
		ICustomerService customerService=new CustomerServiceImpl();
		accounts=customerService.getAccountDetails(customerId);
		System.out.println("Account Number | Account Type | OpeningDate | Opening Balance | Description");
		for(Account account:accounts)
		{
			System.out.println(account.getAccountNumber()+" "+account.getAccountType()+" "+account.getOpeningDate()+" "+
					account.getOpeningBalance()+" "+account.getDescription());
		}
			
	}

}
