package service;

import java.sql.ResultSet;
import java.util.List;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;

public interface ICustomerService {

	Customer createCustomer(Customer customer);

	Address createAddress(Customer customer, Address address);

	Set<Customer> getAllCustomer();

	Set<Address> getAllAddress();

	Account createAccount(Account account);

	Set<Account> getAccountDetails(int customerId);

}
