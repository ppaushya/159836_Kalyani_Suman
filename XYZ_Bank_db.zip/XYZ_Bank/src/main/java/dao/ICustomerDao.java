package dao;

import java.sql.ResultSet;
import java.util.List;
import java.util.Set;

import model.Address;
import model.Customer;

public interface ICustomerDao {

	Customer createCustomer(Customer customer);

	Address createAddress(Customer customer, Address address);

	Set<Customer> getAllCustomer();

	Set<Address> getAllAddress();

}
