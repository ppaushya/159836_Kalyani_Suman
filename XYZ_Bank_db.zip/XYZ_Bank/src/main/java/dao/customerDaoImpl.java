package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;

public class customerDaoImpl implements ICustomerDao {
	
	private Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Customer createCustomer(Customer customer) {

		String query = "INSERT INTO customer (customerId,firstName ,lastName,dateOfBirth,emailId,mobile) VALUES(?,?,?,?,?,?)";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1,customer.getCustomerId());
			statement.setString(2,customer.getFirstName());
			statement.setString(3,customer.getLastName());
			statement.setDate(4,java.sql.Date.valueOf(customer.getDateOfBirth()));
			statement.setString(5, customer.getEmailId());
			statement.setString(6, customer.getMobileNo());
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Customer info inserted");
				query="select * from customer";
				statement=connection.prepareStatement(query);
				ResultSet resultSet= statement.executeQuery();
				Customer  customer1=new Customer();
				while(resultSet.next()) {
					customer1.setCustomerId(resultSet.getInt(1));
					customer1.setFirstName(resultSet.getString(2));
					customer1.setLastName(resultSet.getString(3));
					customer1.setDateOfBirth(resultSet.getDate(4).toLocalDate());
					customer1.setEmailId(resultSet.getString(5));
					customer1.setMobileNo(resultSet.getString(6));
				}
				return customer1;
			}else {System.out.println("Error occured.");}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Address createAddress(Customer customer, Address address) {

		String query="INSERT INTO address(addressId ,addressLine1,addressLine2,city ,state,pincode ,customerId) VALUES"
				+ "(?,?,?,?,?,?,?)";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setInt(1,address.getAddressId());
			statement.setString(2, address.getAddressLine1());
			statement.setString(3, address.getAddressLine2());
			statement.setString(4, address.getCity());
			statement.setString(5, address.getState());
			statement.setString(6, address.getPincode());
			statement.setInt(7, customer.getCustomerId());
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Address info inserted");
				query="select * from address";
				statement=connection.prepareStatement(query);
				ResultSet resultSet= statement.executeQuery();
				Address  address1=new Address();
				while(resultSet.next()) {
					address1.setAddressId(resultSet.getInt(1));
					address1.setAddressLine1(resultSet.getString(2));
					address1.setAddressLine2(resultSet.getString(3));
					address1.setCity(resultSet.getString(4));
					address1.setState(resultSet.getString(5));
					address1.setPincode(resultSet.getString(6));
					address1.setCustomerId(resultSet.getInt(7));
				}
				return address1;
			}else {System.out.println("Error occured.");}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Customer> getAllCustomer() {

		Set<Customer> customers=new HashSet<>();
		Customer customer=new Customer();
		String query="select * from customer";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
		statement=connection.prepareStatement(query);
		ResultSet resultSet= statement.executeQuery();
		while(resultSet.next()) {
			customer.setCustomerId(resultSet.getInt(1));
			customer.setFirstName(resultSet.getString(2));
			customer.setLastName(resultSet.getString(3));
			customer.setDateOfBirth(resultSet.getDate(4).toLocalDate());
			customer.setEmailId(resultSet.getString(5));
			customer.setMobileNo(resultSet.getString(6));
			customers.add(customer);
		}
		
		return customers;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Address> getAllAddress() {

		Set<Address> addresses=new HashSet<>();
		Address address=new Address();
		String query="select * from address";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
		statement=connection.prepareStatement(query);
		ResultSet resultSet= statement.executeQuery();
		while(resultSet.next()) {
			address.setAddressId(resultSet.getInt(1));
			address.setAddressLine1(resultSet.getString(2));
			address.setAddressLine2(resultSet.getString(3));
			address.setCity(resultSet.getString(4));
			address.setState(resultSet.getString(5));
			address.setPincode(resultSet.getString(6));
			address.setCustomerId(resultSet.getInt(7));
			addresses.add(address);
		}
		
		return addresses;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Account createAccount(Account account) {

		String query = "INSERT INTO account (accountType,openingDate,openingBalance,description,customerId) VALUES(?,?,?,?,?)";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setString(1,account.getAccountType());
			statement.setDate(2, java.sql.Date.valueOf(account.getOpeningDate()));
			statement.setDouble(3, account.getOpeningBalance());
			statement.setString(4, account.getDescription());
			statement.setInt(5, account.getCustomerId());
			
			int count = statement.executeUpdate();
			if(count>0) {
				System.out.println("Account info inserted");
				query="select * from account";
				statement=connection.prepareStatement(query);
				ResultSet resultSet= statement.executeQuery();
				Account  account1=new Account();
				while(resultSet.next()) {
					account1.setAccountNumber(resultSet.getInt(1));
					account1.setAccountType(resultSet.getString(2));
					account1.setOpeningDate(resultSet.getDate(3).toLocalDate());
					account1.setOpeningBalance(resultSet.getDouble(4));
					account1.setDescription(resultSet.getString(5));
					account1.setCustomerId(resultSet.getInt(6));
				}
				return account;
			}else {System.out.println("Error occured.");}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Account> getAccountDetails(int custId) {
		Set<Account> accounts=new HashSet<>();
		Account account=new Account();
		String query="select * from account where customerId=custId";
		try(Connection connection = getConnection()) {
			PreparedStatement statement = connection.prepareStatement(query);
		statement=connection.prepareStatement(query);
		ResultSet resultSet= statement.executeQuery();
		while(resultSet.next()) {
			account.setAccountNumber(resultSet.getInt(1));
			account.setAccountType(resultSet.getString(2));
			account.setOpeningDate(resultSet.getDate(3).toLocalDate());
			account.setOpeningBalance(resultSet.getDouble(4));
			account.setDescription(resultSet.getString(5));
			account.setCustomerId(resultSet.getInt(6));
			accounts.add(account);
		}
		
		return accounts;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
