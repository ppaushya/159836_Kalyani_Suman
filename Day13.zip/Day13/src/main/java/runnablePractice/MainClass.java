package runnablePractice;

public class MainClass {

	public static void main(String[] args) {

		ThreadDemo runnable=new ThreadDemo();
		Thread t1=new Thread(runnable,"t1");
		Thread t2=new Thread(runnable);
		Thread t3=new Thread(runnable);
		
		t1.start();
		t2.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//t2.start();
		/*try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		t3.start();*/

	}

}
