package practice;

public class ThreadDemo1 extends Thread{
	
	public ThreadDemo1() {}

	public ThreadDemo1(String threadName)
	{
		super(threadName);
	}
	
	@Override
	public void run()
	{
		System.out.println(getName() +" Thread started........");
		
	}
}
