package practice;

public class MainClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreadDemo1 t1=new ThreadDemo1("t1");
		ThreadDemo1 t2=new ThreadDemo1("t2");
		ThreadDemo1 t3=new ThreadDemo1();
		
		
		t1.start();
		//t1.start();
		System.out.println(t1.getPriority());
		t1.setPriority(Thread.MAX_PRIORITY);
	    t2.start();
		t3.start();
		//will not run in order
		//jvm will provide name if not provided by developer
		//no need to call explicitly run method
	}

}
