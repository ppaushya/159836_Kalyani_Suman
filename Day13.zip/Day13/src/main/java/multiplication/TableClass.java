package multiplication;
//via annonymous object//method 2 for multiply prog
public class TableClass {

	
	public static void main(String[] args) {
	
		ThreadClass table=new ThreadClass(13);
		
		Thread t1=new Thread()
		{
		@Override
		public void run()
		{
			
			//table.setNum(13);
			table.printTable(13);
		}
			};
			t1.start();
			
			Thread t2=new Thread()
			{
			@Override
			public void run()
			{
				
				//table.setNum(15);
				table.printTable(15);
			}
				};
				t2.start();
				
				
				Thread t3=new Thread()
				{
				@Override
				public void run()
				{
					
					//table.setNum(15);
					table.printTable(21);
				}
					};
					t3.start();
	
}
}
