package multiplication;

public class ThreadClass extends Thread{
	
	private int num;
	

	public int getNum() {
		return num;
	}
	synchronized public void setNum(int num) {
		this.num = num;
	}
	public ThreadClass(int num)
	{
		this.num=num;
	}
	
	/*synchronized*/ public void  printTable( )
	{
		synchronized(this) {
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+" : "+num+" * "+i+" = "+(num*i));
		}
		}
	}
	
	public void  printTable(int num )
	{
		synchronized(this) {
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+" : "+num+" * "+i+" = "+(num*i));
		}
		}
	}

	
	
}
