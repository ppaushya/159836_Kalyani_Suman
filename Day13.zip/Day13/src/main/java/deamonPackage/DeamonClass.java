package deamonPackage;



public class DeamonClass {

	public static void main(String[] args) {
		
		ThreadClass runnable1=new ThreadClass(13);
		Thread t1=new Thread(runnable1)
		{
		@Override
		public void run()
		{
			
			runnable1.setNum(13);
			runnable1.printTable();
		}
			};
			t1.start();
			
			
			ThreadClass runnable2=new ThreadClass(13);
			Thread t2=new Thread(runnable2)
			{
			@Override
			public void run()
			{
				
				runnable2.setNum(15);
				runnable2.printTable();
			}
				};
				t2.setDaemon(true);
				t2.start();
				
				System.out.println("Terminated");
	
}
}
