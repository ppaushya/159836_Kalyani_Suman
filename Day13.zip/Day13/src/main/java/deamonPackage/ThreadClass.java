package deamonPackage;

public class ThreadClass implements Runnable{
	
	private int num;
	

	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public ThreadClass(int num)
	{
		this.num=num;
	}
	public void printTable( )
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+" : "+num+" * "+i+" = "+(num*i));
		}
	}

	@Override
	public void run() {
		printTable();
	}
	
}
