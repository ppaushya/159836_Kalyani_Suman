package producerConsumerProblem;

public class MainClass {

	public static void main(String[] args) {
		
		Customer customer=new Customer(1000);
		
		Thread t1=new Thread()
		{
		@Override
		public void run()
		{
			customer.deposit(200);
		}
		};
		t1.start();
		Thread t2=new Thread()
		{
		@Override
		public void run()
		{
			customer.withdraw(240);
		}
		};
		t2.start();
		
	}

}

