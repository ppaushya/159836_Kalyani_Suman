package producerConsumerProblem;

public class Customer extends Thread{
	
	private int balance;
	
	public Customer() {
		super();
	}

	public Customer(int balance) {
		super();
		this.balance = balance;
	}

	synchronized public void withdraw(int amount)
	{
		if(balance<amount)
			this.balance-=amount;
		else
			try {
				wait(100);
				System.out.println("waiting Released");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		notify();
		System.out.println("Notified by withdrwal method");
	}
	
	synchronized public void deposit(int amount)
	{
			this.balance+=balance;
			notify();
			System.out.println("Notified by deposit method");
	}

}
