package synchronizationPractice;


public class MainClass {

	public static void main(String[] args) {

		StaticSync obj=new StaticSync();
		
		Thread t1=new Thread()
		{
		@Override
		public void run()
		{
			StaticSync.staticMethod();
			
		}
			};
			t1.start();
			
			Thread t2=new Thread()
			{
			@Override
			public void run()
			{
				
				StaticSync.staticMethod();
			}
				};
				t2.start();
				
				
				Thread t3=new Thread()
				{
				@Override
				public void run()
				{
					obj.nonStaticMethod();
					
				}
					};
					t3.start();

	}

}
