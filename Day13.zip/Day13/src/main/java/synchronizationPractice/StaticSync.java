package synchronizationPractice;

public class StaticSync extends Thread{

	static String name="tom";
	static int count;
	
	synchronized public static void staticMethod()
	{
		count++;
		for(int i=0;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+"-->"+count++);
		}
	}
	
	public void nonStaticMethod()
	{
		
		for(int i=0;i<=10;i++)
		{
			System.out.println(Thread.currentThread().getName()+"-->"+count);
		}
	}
}
