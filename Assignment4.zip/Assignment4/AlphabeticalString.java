/*package whatever //do not write package name here */
/*Have the function AlphabetSoup(str) take the str string 
parameter being passed and return the string with the letters 
in alphabetical order * (ie. hello becomes ehllo). 
Assume numbers and punctuation symbols will not be included in the string.*/
import java.io.*;
import java.util.*;

class AlphabeticalString {
    public String  AlphabetSoup(String s)
    {
        char[] str=s.toCharArray();
        int size=str.length;
        char temp;
        for(int i=0;i<size;i++)
        {
            for(int j=i+1;j<size;j++)
            {
                if(str[i]>str[j])
                {
                    temp=str[i];
                    str[i]=str[j];
                    str[j]=temp;
                }
            }
        }
        
        s=Arrays.toString(str);
         //System.out.println(str);
         return s;
    }
    public void print(String str)
    {
        int size=str.length();
        //for(int i=0;i<size;i++)
        {
            System.out.println(str);
        }
    }
	public static void main (String[] args) {
	AlphabeticalString obj=new AlphabeticalString();
	String str="hello";
	obj.print(str);
	String s=obj.AlphabetSoup(str);
	obj.print(s);
	}
}