/*Have the function LetterChanges(String str) take the str 
parameter being passed and modify it using the following algorithm.
* Replace every letter in the string with the letter following
it in the alphabet (ie. c becomes d, z becomes a).
* Then capitalize every vowel in this new string (a, e, i, o, u) 
and finally return this modified string.*/
import java.util.*;
public class LetterChange{
    public char[] letterChanges(String str)
    {
        char[] c=new char[str.length()];
		int size=str.length();
		for(int i=0;i<size;i++)
		{
			c[i]=str.charAt(i);
		}
		for(int i=0;i<size;i++)
		{
		    if((int)c[i]>=65 && (int)c[i]<=90)
		    {
		        c[i]=(char) (((int)c[i]+1-65)%26 + 65);
		    }
		    else if((int)c[i]>=97 && (int)c[i]<=122)
		    {
		        c[i]=(char) (((int)c[i]+1-97)%26+97);
		    }
		}
		for(int i=0;i<size;i++)
		{
		    if(c[i]=='a'||c[i]=='e'||c[i]=='i'||c[i]=='o'||c[i]=='u')
		    {
		        if((int)c[i]>=97)
				    c[i]=(char)((int)c[i]-32);
		    }
		}
		return c;
    }
    
    public static void main(String[] args)
    {
        String str;
		
		Scanner sc=new Scanner(System.in);
		LetterChange obj=new LetterChange();
		
		System.out.println("Enter a string with single spaces:");
		str=sc.nextLine();
		
		
		System.out.println("String after modification: ");
		if(obj.letterChanges(str)!=null)
		{
			for(int i=0;i<str.length();i++)
					System.out.print(obj.letterChanges(str)[i]);
		}
		sc.close();
    }
}