/*Check the given String is anagram or not.
Example: Bored = Robed
Save = Vase
Angel = Glean
Stressed = Desserts
Dormitory = Dirty room
School master = The classroom*/

import java.io.*;
import java.util.*;

class Anagram 
{ 
    public boolean isAnagram(String s1,String s2)
    {
        char[] ch1=new char[s1.length()];
		char[] ch2=new char[s2.length()];
		int flag=0;
		
		for(int i=0;i<s1.length();i++)
		{
			ch1[i]=s1.charAt(i);
		}
		for(int i=0;i<s2.length();i++)
		{
			ch2[i]=s2.charAt(i);
		}
		
		if(s1.length()==s2.length())
		{
			for(int i=0;i<s1.length();i++)
			{
				for(int j=0;j<s2.length();j++)
				{
					if(ch1[i]==ch2[j])
						{flag=1;
						break;}
					else 
						flag=0;
					if(j==(s2.length()-1) && flag==0)
						return false;
				}
			}
			return true;
		}
		else 
			return false;
    }
	public static void main (String[] args) {
	    String str1;
	    String str2;
	    
		Scanner sc=new Scanner(System.in);
		Anagram obj=new Anagram();
		
		System.out.println("Enter string1:");
		str1=sc.nextLine();
		System.out.println("Enter string2:");
		str2=sc.nextLine();
		
		if(obj.isAnagram(str1,str2))
		{
		    System.out.println("Given String is Anagram.");
		}
		else
		{
		    System.out.println("Given String is not Anagram.");
		}
		sc.close();
	}
}