/*Have the function ReverseOrder(String str) take the str 
parameter being passed and return the string in reversed order.
*For example: if the input string is "Hello World and Coders" 
then your program should return the string sredoC dna dlroW 
olleH.*/

import java.io.*;
import java.util.*;

public class ReverseString {
    public char[] reverseOrder(String str) 
    {
        char[] c=new char[str.length()];
		int size=str.length();
		for(int i=0;i<size;i++)
		{
			c[i]=str.charAt(i);
		}
		char temp;
		for(int i=0;i<size/2;i++)
		{
		    temp=c[i];
		    c[i]=c[size-1-i];
		    c[size-1-i]=temp;
		}
		return c;
    }
	public static void main (String[] args) {
	    String str;
		Scanner sc=new Scanner(System.in);
		ReverseString obj=new ReverseString();
		
		System.out.println("Enter a string with single spaces:");
		str=sc.nextLine();
		
		
		System.out.println("String after modification: ");
		if(obj.reverseOrder(str)!=null)
		{
			for(int i=0;i<str.length();i++)
					System.out.print(obj.reverseOrder(str)[i]);
		}
		sc.close();
	}
}