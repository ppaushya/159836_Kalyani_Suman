/*Have the function FirstFactorial(int num) take the num 
parameter being passed and return the factorial of it (e.g.
*if num = 4, return (4 * 3 * 2 * 1)). For the test cases, the
range will be between 1 and 18 and the input will always be an 
integer.*/

import java.io.*;
import java.util.*;
public class Factorial{
    public int FirstFactorial(int num)
    {
        int p=1;
        for(int i=2;i<=num;i++)
            p=p*i;
        return p;
    }
    public static void main(String[] args)
    {
        int num;
		Scanner sc=new Scanner(System.in);
		Factorial obj=new Factorial();
		System.out.println("Enter the number:");
		num=sc.nextInt();
		
		System.out.print("Factorial of "+num+"= ");
		System.out.print(obj.FirstFactorial(num));
		sc.close();
    }
}