/*Have the function LongestWord(String sentence) take the 
sentence parameter being passed and return the largest word 
in the string. *If there are two or more words that are the 
same length, return the first word from the string with that 
length.*Ignore punctuation and assume sentence will nt be empty.*/

import java.io.*;
import java.util.*;

class LongestWordLength 
{ 
    static int LongestWord(String str) 
    { 
    int n = str.length(); 
    int res = 0, curr_len = 0; 
    for (int i = 0; i < n; i++) 
    { 
       if (str.charAt(i) != ' ') 
           { 
               curr_len++; 
           }
        else
        { 
            res = Math.max(res, curr_len); 
            curr_len = 0; 
        } 
    } 
    return Math.max(res, curr_len); 
    }
    public char[] printWord(String str,int size)
    {
         int n = str.length(); 
         int res = 0, curr_len = 0; 
        char[] word=new char[n];
        int j=0;
        for (int i = 0; i < n; i++) 
    {
        if (str.charAt(i) != ' ') 
           { 
               curr_len++; 
               word[j]=str.charAt(i);
               j++;
               
           }
        else
        { 
            if(res<curr_len)
            {
                j=0;
            }
            res = Math.max(res, curr_len); 
            
            curr_len = 0; 
        } 
    }
        return word;
    } 
     
    
	public static void main (String[] args) {
	    String str;
	    
		Scanner sc=new Scanner(System.in);
		LongestWordLength obj=new LongestWordLength();
		
		System.out.println("Enter a string with single spaces:");
		str=sc.nextLine();
		
		System.out.println("Longest word length is ");
		int len=obj.LongestWord(str);
		System.out.println(len);
	    char[] word=obj.printWord(str,len);
	    for(int i=0;i<len;i++)
	        System.out.print(word[i]);
		sc.close();
	}
}